
<div class="footer-bottom bg-light-blue-active">
        <div class="container pt-10 pb-0 container-center">
            <div class="row">
                <div class="col-md-6 sm-text-center">
                    <p class="font-13 text-black-777 m-0">Copyright &copy;<script>document.write(new Date().getFullYear());</script> UBERAMBULANCE. Tout Droits Réservés</p>
                </div>
                <div class="col-md-6 text-right flip sm-text-center">
                    <div class="widget no-border m-0">
                        <ul class="styled-icons icon-dark icon-circled icon-sm">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#"><i class="fa fa-skype"></i></a></li>
                            <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
