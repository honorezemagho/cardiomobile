
<body >
<div id="wrapper">

    <!-- Header -->
    <header id="header" class="header text-theme">
        <div class="header-nav">
            <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
                <div class="container col-sm-2">
                    <nav id="menuzord" class="menuzord blue no-bg">
                        <a class="menuzord-brand pull-left flip mb-15 bg-dark-transparent-9"   href="/">CARDIO<span class="text-theme-colored">MOBILE</span></a>
                    </nav>
                </div>

                <div class="container col-sm-10">
                <marquee behavior="scroll" direction="left" scrollamount="10">
                    <h3> Pour Toute Urgence, Envoyez par sms <b>"SECOURS"</b> AU 8735, c'est gratuit, disponible 24H/24, 7J/7</h3>
                </marquee>
            </div>
            </div>
        </div>
    </header>
