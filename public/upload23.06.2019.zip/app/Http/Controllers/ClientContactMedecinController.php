<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ville;
use App\Quartier;
use App\Medecin;
use App\Http\Requests\ContactMedecinRequest;
use App\Urgence;
use Illuminate\Http\Resources\Json\JsonResource;
use GuzzleHttp\Exception\GuzzleException;
use GuzzleHttp\Client;

class ClientContactMedecinController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        return view('urgence.index');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }



    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(ContactMedecinRequest $request)
    {
        //
        $input = $request->all();


       /*Urgence::create($input);*/


       $destinataires = Medecin::Where('quartier_id', $input['quartier_id'])->get('phone');


        $string = '';
        foreach( $destinataires as $key =>$destinataire){

            $string .= '+237'.$destinataire->phone;

        }



    $message = 'Êtes-vous disponible pour une urgence concernant  '.$input['description'].'  dans 5 Minutes';

        $send = "http://5.39.75.139:22140/message?user=digis&pass=digis123&from=8002&to=$string&flash=".$message."&dlrreq=1";

     /*      $client = new \GuzzleHttp\Client();

     // Create a request
             $request = $client->get($send);
// Get the actual response without headers
           $response = $request->getBody();
           echo $response;*/


        /*     $url = 'http://mmp.gts-infotel.com/gts/sendsinglebulk';

             $YourMobilePhone = 673004266;
             $YourPassword = '07081999A';
             $Sender_ID=680;

             $fields = array(

                 'phone' => $YourMobilePhone,

                 'password' => $YourPassword,

                 'sender_id' => $Sender_ID,

                 'contact_list' => [$string],

                 'message' => $message
             );


             	$ch = curl_init($url);

	curl_setopt($ch, CURLOPT_POST, 1);

	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));

	curl_setopt($ch, CURLOPT_HTTPHEADER,  array('Content-Type: application/x-www-form-urlencoded'));

	$result = curl_exec($ch);

	$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	 print_r($httpCode);
	if($httpCode == 200){ //******* well received on our plateform
        if($result == 200){//****** wel transmitted to our Gatteway connect to SMSC Operators
                echo '  Message envoyé avec succès';
        }else{
            echo 'Message non envoyé';
        }
    }*/
        return $send;
       /* return redirect('');*/

       /* return redirect('urgence.index');*/

        /*return view('urgence.index', compact('destinataires', 'message'));*/
    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
