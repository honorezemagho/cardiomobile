(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){'use strict';function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{'default':obj};}
var _libJsIndexJs=require('./lib/js/index.js');var _libJsIndexJs2=_interopRequireDefault(_libJsIndexJs);window.MaterialDatePicker=_libJsIndexJs2['default'];},{"./lib/js/index.js":3}],2:[function(require,module,exports){'use strict';Object.defineProperty(exports,'__esModule',{value:true});var _slice=Array.prototype.slice;var _createClass=(function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if('value'in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};})();function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError('Cannot call a class as a function');}}
var Events=(function(){function Events(){_classCallCheck(this,Events);this._events={'*':[]};}
_createClass(Events,[{key:'trigger',value:function trigger(eventName,evtData){var _this=this;eventName.split(' ').forEach(function(evtName){_this._events['*'].forEach(function(evt){return evt.fn.call(evt.scope,evtName,evtData);});if(_this._events[evtName]){_this._events[evtName].forEach(function(evt){evt.fn.call(evt.scope,evtData);});}});return this;}},{key:'on',value:function on(eventName,fn,scope){if(!this._events[eventName])this._events[eventName]=[];this._events[eventName].push({eventName:eventName,fn:fn,scope:scope||this});return this;}},{key:'off',value:function off(eventName,fn){if(!this._events[eventName])return this;if(!fn){this._events[eventName]=[];}
this._events[eventName]=this._events[eventName].filter(function(evt){return evt.fn!==fn;});return this;}},{key:'once',value:function once(eventName,fn,scope){var _arguments=arguments,_this2=this;var func=function func(){fn.call.apply(fn,[scope].concat(_slice.call(_arguments)));_this2.off(eventName,func);};return this.on(eventName,func,scope);}}]);return Events;})();exports['default']=Events;module.exports=exports['default'];},{}],3:[function(require,module,exports){'use strict';Object.defineProperty(exports,'__esModule',{value:true});var _createClass=(function(){function defineProperties(target,props){for(var i=0;i<props.length;i++){var descriptor=props[i];descriptor.enumerable=descriptor.enumerable||false;descriptor.configurable=true;if('value'in descriptor)descriptor.writable=true;Object.defineProperty(target,descriptor.key,descriptor);}}return function(Constructor,protoProps,staticProps){if(protoProps)defineProperties(Constructor.prototype,protoProps);if(staticProps)defineProperties(Constructor,staticProps);return Constructor;};})();var _get=function get(_x,_x2,_x3){var _again=true;_function:while(_again){var object=_x,property=_x2,receiver=_x3;_again=false;if(object===null)object=Function.prototype;var desc=Object.getOwnPropertyDescriptor(object,property);if(desc===undefined){var parent=Object.getPrototypeOf(object);if(parent===null){return undefined;}else{_x=parent;_x2=property;_x3=receiver;_again=true;desc=parent=undefined;continue _function;}}else if('value'in desc){return desc.value;}else{var getter=desc.get;if(getter===undefined){return undefined;}return getter.call(receiver);}}};function _interopRequireDefault(obj){return obj&&obj.__esModule?obj:{'default':obj};}
function _toConsumableArray(arr){if(Array.isArray(arr)){for(var i=0,arr2=Array(arr.length);i<arr.length;i++)arr2[i]=arr[i];return arr2;}else{return Array.from(arr);}}
function _classCallCheck(instance,Constructor){if(!(instance instanceof Constructor)){throw new TypeError('Cannot call a class as a function');}}
function _inherits(subClass,superClass){if(typeof superClass!=='function'&&superClass!==null){throw new TypeError('Super expression must either be null or a function, not '+typeof superClass);}subClass.prototype=Object.create(superClass&&superClass.prototype,{constructor:{value:subClass,enumerable:false,writable:true,configurable:true}});if(superClass)Object.setPrototypeOf?Object.setPrototypeOf(subClass,superClass):subClass.__proto__=superClass;}
var _rome=require('rome');var _rome2=_interopRequireDefault(_rome);var _lodashObjectDefaults=require('lodash/object/defaults');var _lodashObjectDefaults2=_interopRequireDefault(_lodashObjectDefaults);var _moment=require('moment');var _moment2=_interopRequireDefault(_moment);var _templateDatepickerHbs=require('../template/datepicker.hbs');var _templateDatepickerHbs2=_interopRequireDefault(_templateDatepickerHbs);var _templateScrimHbs=require('../template/scrim.hbs');var _templateScrimHbs2=_interopRequireDefault(_templateScrimHbs);var _events=require('./events');var _events2=_interopRequireDefault(_events);var prefix='c-datepicker';var defaults={'default':(0,_moment2['default'])().startOf('hour'),styles:{scrim:'c-scrim',back:prefix+'__back',container:prefix+'__calendar',date:prefix+'__date',dayBody:prefix+'__days-body',dayBodyElem:prefix+'__day-body',dayConcealed:prefix+'__day--concealed',dayDisabled:prefix+'__day--disabled',dayHead:prefix+'__days-head',dayHeadElem:prefix+'__day-head',dayRow:prefix+'__days-row',dayTable:prefix+'__days',month:prefix+'__month',next:prefix+'__next',positioned:prefix+'--fixed',selectedDay:prefix+'__day--selected',selectedTime:prefix+'__time--selected',time:prefix+'__time',timeList:prefix+'__time-list',timeOption:prefix+'__time-option',clockNum:prefix+'__clock__num'},format:'dd/MM/YY',container:document.body,dateValidator:undefined};var DateTimePicker=(function(_Events){_inherits(DateTimePicker,_Events);function DateTimePicker(options){var _this=this;_classCallCheck(this,DateTimePicker);_get(Object.getPrototypeOf(DateTimePicker.prototype),'constructor',this).call(this);this.options=(0,_lodashObjectDefaults2['default'])({},options,defaults);this.value=this.options['default'];this.on('*',function(evtName,evtData){if(_this.options.el){var _event=new CustomEvent(evtName,_this,evtData);_this.options.el.dispatchEvent(_event);}});}
_createClass(DateTimePicker,[{key:'initializeRome',value:function initializeRome(container,validator){var _this2=this;return(0,_rome2['default'])(container,{styles:this.options.styles,time:false,dateValidator:validator}).on('data',function(value){return _this2.set(value);});}},{key:'open',value:function open(){var scrimEl=_templateScrimHbs2['default'].replace('{{styles.scrim}}',this.options.styles.scrim);_appendTemplate(document.body,scrimEl);_appendTemplate(this.options.container,_templateDatepickerHbs2['default']);this.pickerEl=this.options.container.querySelector('.'+prefix);this.scrimEl=this.options.container.querySelector('.'+this.options.styles.scrim);this.amToggleEl=this.$('.c-datepicker__clock--am');this.pmToggleEl=this.$('.c-datepicker__clock--pm');this.set(this.value||this.options['default'],{silent:true});this.initializeRome(this.$('.'+this.options.styles.container),this.options.dateValidator);this._show();}},{key:'close',value:function close(){this._hide();}},{key:'_hide',value:function _hide(){var _this3=this;this.pickerEl.classList.remove('open');window.setTimeout(function(){_this3.options.container.removeChild(_this3.pickerEl);document.body.removeChild(_this3.scrimEl);_this3.trigger('close');},200);return this;}},{key:'_show',value:function _show(){var _this4=this;this.delegateEvents();window.requestAnimationFrame(function(){_this4.scrimEl.classList.add(_this4.options.styles.scrim+'--shown');_this4.pickerEl.classList.add(prefix+'--open');_this4.trigger('open');});return this;}},{key:'delegateEvents',value:function delegateEvents(){var _this5=this;this.$('.js-cancel').addEventListener('click',function(){return _this5.clickCancel();},false);this.$('.js-ok').addEventListener('click',function(){return _this5.clickSubmit();},false);this.$('.'+this.options.styles.clockNum).forEach(function(el){el.addEventListener('click',function(e){return _this5.clickClock(e);},false);});this.$('.c-datepicker__clock--am').addEventListener('click',function(e){return _this5.clickAm(e);},false);this.$('.c-datepicker__clock--pm').addEventListener('click',function(e){return _this5.clickPm(e);},false);return this;}},{key:'clickSubmit',value:function clickSubmit(){this.close();this.trigger('submit',this.value,this);return this;}},{key:'clickCancel',value:function clickCancel(){this.close();this.trigger('cancel',this.value,this);return this;}},{key:'clickClock',value:function clickClock(e){var number=parseInt(e.currentTarget.getAttribute('data-number'),10);if(number===0&&this.meridiem==='pm'){number=12;}else if(this.meridiem==='pm'){number+=12;}
this.value.hour(number);this.setTime(this.value);return this;}},{key:'clickAm',value:function clickAm(){if(this.meridiem==='pm'){this.meridiem='am';this.value.hour(this.value.hour()+12);}
this.setTime(this.value);return this;}},{key:'clickPm',value:function clickPm(){if(this.meridiem==='am'){this.meridiem='pm';this.value.hour(this.value.hour()-12);}
this.setTime(this.value);return this;}},{key:'data',value:function data(val){return val?this.set(val):this.value;}},{key:'set',value:function set(value,opts){var m=(0,_moment2['default'])(value);var evts=[];if(!this.value||this.value&&(m.date()!==this.value.date()||m.month()!==this.value.month()||m.year()!==this.value.year())){this.setDate(m);evts.push('change:date');}else{this.setTime(m);evts.push('change:time');}
if(this.options.el){if(this.options.el.tagName==='INPUT'){this.options.el.value=m.format(this.options.format);}else{this.options.el.setAttribute('data-value',m.format(this.options.format));}}
if(!opts||!opts.silent){this.trigger(['change'].concat(evts).join(' '),this.value,this);}}},{key:'setDate',value:function setDate(date){var m=(0,_moment2['default'])(date);var month=m.format('MMM');var day=m.format('Do');var dayOfWeek=m.format('dddd');var year=m.format('YYYY');this.$('.js-day').innerText=dayOfWeek;this.$('.js-date-month').innerText=month+' '+year;this.$('.js-date-day').innerText=day;this.value.year(m.year());this.value.month(m.month());this.value.date(m.date());return this;}},{key:'setTime',value:function setTime(time){var m=(0,_moment2['default'])(time);var hour=m.format('HH');var hourAsInt=parseInt(hour,10)%12;this.$('.js-date-hours').innerText=hour;this.$('.c-datepicker__clock__hours .'+this.options.styles.clockNum+'[data-number="'+hourAsInt+'"]').classList.add('.'+this.options.styles.clockNum+'--active');this.value.hours(m.hours());this.meridiem=this.value.format('a');if(this.meridiem==='pm'){this.amToggleEl.removeAttribute('checked');this.pmToggleEl.setAttribute('checked','checked');this.amToggleEl.parentElement.classList.remove('c-datepicker__toggle--checked');this.pmToggleEl.parentElement.classList.add('c-datepicker__toggle--checked');}else{this.pmToggleEl.removeAttribute('checked');this.amToggleEl.setAttribute('checked','checked');this.pmToggleEl.parentElement.classList.remove('c-datepicker__toggle--checked');this.amToggleEl.parentElement.classList.add('c-datepicker__toggle--checked');}
return this;}},{key:'$',value:function $(selector){var els=this.pickerEl.querySelectorAll(selector);return els.length>1?[].concat(_toConsumableArray(els)):els[0];}}]);return DateTimePicker;})(_events2['default']);exports['default']=DateTimePicker;function _appendTemplate(parent,template){var tempEl=document.createElement('div');tempEl.innerHTML=template;parent.appendChild(tempEl.firstChild);return this;}
module.exports=exports['default'];},{"../template/datepicker.hbs":4,"../template/scrim.hbs":5,"./events":2,"lodash/object/defaults":29,"moment":33,"rome":78}],4:[function(require,module,exports){module.exports="<div class=\"c-datepicker\">\n  <input class=\"c-datepicker__toggle c-datepicker__toggle--right c-datepicker--show-time\" type=\"radio\" name=\"date-toggle\" value=\"time\" >\n\n  <input class=\"c-datepicker__toggle c-datepicker__toggle--left  c-datepicker--show-calendar\" type=\"radio\" name=\"date-toggle\" value=\"calendar\" checked>\n\n  <div class=\"c-datepicker__header\">\n    <div class=\"c-datepicker__header-day\">\n      <span class=\"js-day\">Monday</span>\n    </div>\n    <div class=\"c-datepicker__header-date\">\n      <span class=\"c-datepicker__header-date__month js-date-month\">Jan 2015</span>\n      <span class=\"c-datepicker__header-date__day js-date-day\">10th</span>\n      <span class=\"c-datepicker__header-date__time js-date-time\">\n        <span class=\"c-datepicker__header-date__hours js-date-hours\">09</span>:<span class=\"c-datepicker__header-date__minutes js-date-minutes\">00</span>\n      </span>\n    </div>\n  </div>\n\n  <div class=\"c-datepicker__calendar\"></div>\n  <div class=\"c-datepicker__clock\">\n    <div class=\"c-datepicker__clock__am-pm-toggle\">\n      <label class=\"c-datepicker__toggle--checked\">\n        <input checked=\"checked\" class=\"c-datepicker__toggle c-datepicker__toggle--right c-datepicker__clock--am\" type=\"radio\" name=\"time-date-toggle\" value=\"AM\" />\n        AM\n      </label>\n\n      <label>\n        <input class=\"c-datepicker__toggle c-datepicker__toggle--right c-datepicker__clock--pm\" type=\"radio\" name=\"time-date-toggle\" value=\"PM\" />\n        PM\n      </label>\n    </div>\n\n    <div class=\"c-datepicker__clock__hours\">\n      <div class=\"c-datepicker__clock__num\" data-number=\"3\">3</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"4\">4</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"5\">5</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"6\">6</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"7\">7</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"8\">8</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"9\">9</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"10\">10</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"11\">11</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"0\">12</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"1\">1</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"2\">2</div>\n      <div class=\"c-datepicker__clock-hands\">\n        <div class=\"c-datepicker__hour-hand\"></div>\n      </div>\n    </div>\n    <div class=\"c-datepicker__clock__minutes\">\n      <div class=\"c-datepicker__clock__num\" data-number=\"15\">15</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"20\">20</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"25\">25</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"30\">30</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"35\">35</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"40\">40</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"45\">45</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"50\">50</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"55\">55</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"0\">0</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"5\">5</div>\n      <div class=\"c-datepicker__clock__num\" data-number=\"10\">10</div>\n      <div class=\"c-datepicker__clock-hands\">\n        <div class=\"c-datepicker__hour-hand\"></div>\n      </div>\n    </div>\n  </div>\n  <div class=\"modal-btns\">\n    <a class=\"c-btn c-btn--flat js-cancel\">Cancel</a>\n    <a class=\"c-btn c-btn--flat js-ok\">OK</a>\n  </div>\n</div>";},{}],5:[function(require,module,exports){module.exports="<div class=\"{{styles.scrim}}\"></div>";},{}],6:[function(require,module,exports){var FUNC_ERROR_TEXT='Expected a function';var nativeMax=Math.max;function restParam(func,start){if(typeof func!='function'){throw new TypeError(FUNC_ERROR_TEXT);}
start=nativeMax(start===undefined?(func.length-1):(+start||0),0);return function(){var args=arguments,index=-1,length=nativeMax(args.length-start,0),rest=Array(length);while(++index<length){rest[index]=args[start+index];}
switch(start){case 0:return func.call(this,rest);case 1:return func.call(this,args[0],rest);case 2:return func.call(this,args[0],args[1],rest);}
var otherArgs=Array(start+1);index=-1;while(++index<start){otherArgs[index]=args[index];}
otherArgs[start]=rest;return func.apply(this,otherArgs);};}
module.exports=restParam;},{}],7:[function(require,module,exports){function assignDefaults(objectValue,sourceValue){return objectValue===undefined?sourceValue:objectValue;}
module.exports=assignDefaults;},{}],8:[function(require,module,exports){var keys=require('../object/keys');function assignWith(object,source,customizer){var index=-1,props=keys(source),length=props.length;while(++index<length){var key=props[index],value=object[key],result=customizer(value,source[key],key,object,source);if((result===result?(result!==value):(value===value))||(value===undefined&&!(key in object))){object[key]=result;}}
return object;}
module.exports=assignWith;},{"../object/keys":30}],9:[function(require,module,exports){var baseCopy=require('./baseCopy'),keys=require('../object/keys');function baseAssign(object,source){return source==null?object:baseCopy(source,keys(source),object);}
module.exports=baseAssign;},{"../object/keys":30,"./baseCopy":10}],10:[function(require,module,exports){function baseCopy(source,props,object){object||(object={});var index=-1,length=props.length;while(++index<length){var key=props[index];object[key]=source[key];}
return object;}
module.exports=baseCopy;},{}],11:[function(require,module,exports){function baseProperty(key){return function(object){return object==null?undefined:object[key];};}
module.exports=baseProperty;},{}],12:[function(require,module,exports){var identity=require('../utility/identity');function bindCallback(func,thisArg,argCount){if(typeof func!='function'){return identity;}
if(thisArg===undefined){return func;}
switch(argCount){case 1:return function(value){return func.call(thisArg,value);};case 3:return function(value,index,collection){return func.call(thisArg,value,index,collection);};case 4:return function(accumulator,value,index,collection){return func.call(thisArg,accumulator,value,index,collection);};case 5:return function(value,other,key,object,source){return func.call(thisArg,value,other,key,object,source);};}
return function(){return func.apply(thisArg,arguments);};}
module.exports=bindCallback;},{"../utility/identity":32}],13:[function(require,module,exports){var bindCallback=require('./bindCallback'),isIterateeCall=require('./isIterateeCall'),restParam=require('../function/restParam');function createAssigner(assigner){return restParam(function(object,sources){var index=-1,length=object==null?0:sources.length,customizer=length>2?sources[length-2]:undefined,guard=length>2?sources[2]:undefined,thisArg=length>1?sources[length-1]:undefined;if(typeof customizer=='function'){customizer=bindCallback(customizer,thisArg,5);length-=2;}else{customizer=typeof thisArg=='function'?thisArg:undefined;length-=(customizer?1:0);}
if(guard&&isIterateeCall(sources[0],sources[1],guard)){customizer=length<3?undefined:customizer;length=1;}
while(++index<length){var source=sources[index];if(source){assigner(object,source,customizer);}}
return object;});}
module.exports=createAssigner;},{"../function/restParam":6,"./bindCallback":12,"./isIterateeCall":19}],14:[function(require,module,exports){var restParam=require('../function/restParam');function createDefaults(assigner,customizer){return restParam(function(args){var object=args[0];if(object==null){return object;}
args.push(customizer);return assigner.apply(undefined,args);});}
module.exports=createDefaults;},{"../function/restParam":6}],15:[function(require,module,exports){var baseProperty=require('./baseProperty');var getLength=baseProperty('length');module.exports=getLength;},{"./baseProperty":11}],16:[function(require,module,exports){var isNative=require('../lang/isNative');function getNative(object,key){var value=object==null?undefined:object[key];return isNative(value)?value:undefined;}
module.exports=getNative;},{"../lang/isNative":26}],17:[function(require,module,exports){var getLength=require('./getLength'),isLength=require('./isLength');function isArrayLike(value){return value!=null&&isLength(getLength(value));}
module.exports=isArrayLike;},{"./getLength":15,"./isLength":20}],18:[function(require,module,exports){var reIsUint=/^\d+$/;var MAX_SAFE_INTEGER=9007199254740991;function isIndex(value,length){value=(typeof value=='number'||reIsUint.test(value))?+value:-1;length=length==null?MAX_SAFE_INTEGER:length;return value>-1&&value%1==0&&value<length;}
module.exports=isIndex;},{}],19:[function(require,module,exports){var isArrayLike=require('./isArrayLike'),isIndex=require('./isIndex'),isObject=require('../lang/isObject');function isIterateeCall(value,index,object){if(!isObject(object)){return false;}
var type=typeof index;if(type=='number'?(isArrayLike(object)&&isIndex(index,object.length)):(type=='string'&&index in object)){var other=object[index];return value===value?(value===other):(other!==other);}
return false;}
module.exports=isIterateeCall;},{"../lang/isObject":27,"./isArrayLike":17,"./isIndex":18}],20:[function(require,module,exports){var MAX_SAFE_INTEGER=9007199254740991;function isLength(value){return typeof value=='number'&&value>-1&&value%1==0&&value<=MAX_SAFE_INTEGER;}
module.exports=isLength;},{}],21:[function(require,module,exports){function isObjectLike(value){return!!value&&typeof value=='object';}
module.exports=isObjectLike;},{}],22:[function(require,module,exports){var isArguments=require('../lang/isArguments'),isArray=require('../lang/isArray'),isIndex=require('./isIndex'),isLength=require('./isLength'),keysIn=require('../object/keysIn');var objectProto=Object.prototype;var hasOwnProperty=objectProto.hasOwnProperty;function shimKeys(object){var props=keysIn(object),propsLength=props.length,length=propsLength&&object.length;var allowIndexes=!!length&&isLength(length)&&(isArray(object)||isArguments(object));var index=-1,result=[];while(++index<propsLength){var key=props[index];if((allowIndexes&&isIndex(key,length))||hasOwnProperty.call(object,key)){result.push(key);}}
return result;}
module.exports=shimKeys;},{"../lang/isArguments":23,"../lang/isArray":24,"../object/keysIn":31,"./isIndex":18,"./isLength":20}],23:[function(require,module,exports){var isArrayLike=require('../internal/isArrayLike'),isObjectLike=require('../internal/isObjectLike');var objectProto=Object.prototype;var hasOwnProperty=objectProto.hasOwnProperty;var propertyIsEnumerable=objectProto.propertyIsEnumerable;function isArguments(value){return isObjectLike(value)&&isArrayLike(value)&&hasOwnProperty.call(value,'callee')&&!propertyIsEnumerable.call(value,'callee');}
module.exports=isArguments;},{"../internal/isArrayLike":17,"../internal/isObjectLike":21}],24:[function(require,module,exports){var getNative=require('../internal/getNative'),isLength=require('../internal/isLength'),isObjectLike=require('../internal/isObjectLike');var arrayTag='[object Array]';var objectProto=Object.prototype;var objToString=objectProto.toString;var nativeIsArray=getNative(Array,'isArray');var isArray=nativeIsArray||function(value){return isObjectLike(value)&&isLength(value.length)&&objToString.call(value)==arrayTag;};module.exports=isArray;},{"../internal/getNative":16,"../internal/isLength":20,"../internal/isObjectLike":21}],25:[function(require,module,exports){var isObject=require('./isObject');var funcTag='[object Function]';var objectProto=Object.prototype;var objToString=objectProto.toString;function isFunction(value){return isObject(value)&&objToString.call(value)==funcTag;}
module.exports=isFunction;},{"./isObject":27}],26:[function(require,module,exports){var isFunction=require('./isFunction'),isObjectLike=require('../internal/isObjectLike');var reIsHostCtor=/^\[object .+?Constructor\]$/;var objectProto=Object.prototype;var fnToString=Function.prototype.toString;var hasOwnProperty=objectProto.hasOwnProperty;var reIsNative=RegExp('^'+
fnToString.call(hasOwnProperty).replace(/[\\^$.*+?()[\]{}|]/g,'\\$&').replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,'$1.*?')+'$');function isNative(value){if(value==null){return false;}
if(isFunction(value)){return reIsNative.test(fnToString.call(value));}
return isObjectLike(value)&&reIsHostCtor.test(value);}
module.exports=isNative;},{"../internal/isObjectLike":21,"./isFunction":25}],27:[function(require,module,exports){function isObject(value){var type=typeof value;return!!value&&(type=='object'||type=='function');}
module.exports=isObject;},{}],28:[function(require,module,exports){var assignWith=require('../internal/assignWith'),baseAssign=require('../internal/baseAssign'),createAssigner=require('../internal/createAssigner');var assign=createAssigner(function(object,source,customizer){return customizer?assignWith(object,source,customizer):baseAssign(object,source);});module.exports=assign;},{"../internal/assignWith":8,"../internal/baseAssign":9,"../internal/createAssigner":13}],29:[function(require,module,exports){var assign=require('./assign'),assignDefaults=require('../internal/assignDefaults'),createDefaults=require('../internal/createDefaults');var defaults=createDefaults(assign,assignDefaults);module.exports=defaults;},{"../internal/assignDefaults":7,"../internal/createDefaults":14,"./assign":28}],30:[function(require,module,exports){var getNative=require('../internal/getNative'),isArrayLike=require('../internal/isArrayLike'),isObject=require('../lang/isObject'),shimKeys=require('../internal/shimKeys');var nativeKeys=getNative(Object,'keys');var keys=!nativeKeys?shimKeys:function(object){var Ctor=object==null?undefined:object.constructor;if((typeof Ctor=='function'&&Ctor.prototype===object)||(typeof object!='function'&&isArrayLike(object))){return shimKeys(object);}
return isObject(object)?nativeKeys(object):[];};module.exports=keys;},{"../internal/getNative":16,"../internal/isArrayLike":17,"../internal/shimKeys":22,"../lang/isObject":27}],31:[function(require,module,exports){var isArguments=require('../lang/isArguments'),isArray=require('../lang/isArray'),isIndex=require('../internal/isIndex'),isLength=require('../internal/isLength'),isObject=require('../lang/isObject');var objectProto=Object.prototype;var hasOwnProperty=objectProto.hasOwnProperty;function keysIn(object){if(object==null){return[];}
if(!isObject(object)){object=Object(object);}
var length=object.length;length=(length&&isLength(length)&&(isArray(object)||isArguments(object))&&length)||0;var Ctor=object.constructor,index=-1,isProto=typeof Ctor=='function'&&Ctor.prototype===object,result=Array(length),skipIndexes=length>0;while(++index<length){result[index]=(index+'');}
for(var key in object){if(!(skipIndexes&&isIndex(key,length))&&!(key=='constructor'&&(isProto||!hasOwnProperty.call(object,key)))){result.push(key);}}
return result;}
module.exports=keysIn;},{"../internal/isIndex":18,"../internal/isLength":20,"../lang/isArguments":23,"../lang/isArray":24,"../lang/isObject":27}],32:[function(require,module,exports){function identity(value){return value;}
module.exports=identity;},{}],33:[function(require,module,exports){(function(global,factory){typeof exports==='object'&&typeof module!=='undefined'?module.exports=factory():typeof define==='function'&&define.amd?define(factory):global.moment=factory()}(this,function(){'use strict';var hookCallback;function utils_hooks__hooks(){return hookCallback.apply(null,arguments);}
function setHookCallback(callback){hookCallback=callback;}
function isArray(input){return Object.prototype.toString.call(input)==='[object Array]';}
function isDate(input){return input instanceof Date||Object.prototype.toString.call(input)==='[object Date]';}
function map(arr,fn){var res=[],i;for(i=0;i<arr.length;++i){res.push(fn(arr[i],i));}
return res;}
function hasOwnProp(a,b){return Object.prototype.hasOwnProperty.call(a,b);}
function extend(a,b){for(var i in b){if(hasOwnProp(b,i)){a[i]=b[i];}}
if(hasOwnProp(b,'toString')){a.toString=b.toString;}
if(hasOwnProp(b,'valueOf')){a.valueOf=b.valueOf;}
return a;}
function create_utc__createUTC(input,format,locale,strict){return createLocalOrUTC(input,format,locale,strict,true).utc();}
function defaultParsingFlags(){return{empty:false,unusedTokens:[],unusedInput:[],overflow:-2,charsLeftOver:0,nullInput:false,invalidMonth:null,invalidFormat:false,userInvalidated:false,iso:false};}
function getParsingFlags(m){if(m._pf==null){m._pf=defaultParsingFlags();}
return m._pf;}
function valid__isValid(m){if(m._isValid==null){var flags=getParsingFlags(m);m._isValid=!isNaN(m._d.getTime())&&flags.overflow<0&&!flags.empty&&!flags.invalidMonth&&!flags.invalidWeekday&&!flags.nullInput&&!flags.invalidFormat&&!flags.userInvalidated;if(m._strict){m._isValid=m._isValid&&flags.charsLeftOver===0&&flags.unusedTokens.length===0&&flags.bigHour===undefined;}}
return m._isValid;}
function valid__createInvalid(flags){var m=create_utc__createUTC(NaN);if(flags!=null){extend(getParsingFlags(m),flags);}
else{getParsingFlags(m).userInvalidated=true;}
return m;}
var momentProperties=utils_hooks__hooks.momentProperties=[];function copyConfig(to,from){var i,prop,val;if(typeof from._isAMomentObject!=='undefined'){to._isAMomentObject=from._isAMomentObject;}
if(typeof from._i!=='undefined'){to._i=from._i;}
if(typeof from._f!=='undefined'){to._f=from._f;}
if(typeof from._l!=='undefined'){to._l=from._l;}
if(typeof from._strict!=='undefined'){to._strict=from._strict;}
if(typeof from._tzm!=='undefined'){to._tzm=from._tzm;}
if(typeof from._isUTC!=='undefined'){to._isUTC=from._isUTC;}
if(typeof from._offset!=='undefined'){to._offset=from._offset;}
if(typeof from._pf!=='undefined'){to._pf=getParsingFlags(from);}
if(typeof from._locale!=='undefined'){to._locale=from._locale;}
if(momentProperties.length>0){for(i in momentProperties){prop=momentProperties[i];val=from[prop];if(typeof val!=='undefined'){to[prop]=val;}}}
return to;}
var updateInProgress=false;function Moment(config){copyConfig(this,config);this._d=new Date(config._d!=null?config._d.getTime():NaN);if(updateInProgress===false){updateInProgress=true;utils_hooks__hooks.updateOffset(this);updateInProgress=false;}}
function isMoment(obj){return obj instanceof Moment||(obj!=null&&obj._isAMomentObject!=null);}
function absFloor(number){if(number<0){return Math.ceil(number);}else{return Math.floor(number);}}
function toInt(argumentForCoercion){var coercedNumber=+argumentForCoercion,value=0;if(coercedNumber!==0&&isFinite(coercedNumber)){value=absFloor(coercedNumber);}
return value;}
function compareArrays(array1,array2,dontConvert){var len=Math.min(array1.length,array2.length),lengthDiff=Math.abs(array1.length-array2.length),diffs=0,i;for(i=0;i<len;i++){if((dontConvert&&array1[i]!==array2[i])||(!dontConvert&&toInt(array1[i])!==toInt(array2[i]))){diffs++;}}
return diffs+lengthDiff;}
function Locale(){}
var locales={};var globalLocale;function normalizeLocale(key){return key?key.toLowerCase().replace('_','-'):key;}
function chooseLocale(names){var i=0,j,next,locale,split;while(i<names.length){split=normalizeLocale(names[i]).split('-');j=split.length;next=normalizeLocale(names[i+1]);next=next?next.split('-'):null;while(j>0){locale=loadLocale(split.slice(0,j).join('-'));if(locale){return locale;}
if(next&&next.length>=j&&compareArrays(split,next,true)>=j-1){break;}
j--;}
i++;}
return null;}
function loadLocale(name){var oldLocale=null;if(!locales[name]&&typeof module!=='undefined'&&module&&module.exports){try{oldLocale=globalLocale._abbr;require('./locale/'+name);locale_locales__getSetGlobalLocale(oldLocale);}catch(e){}}
return locales[name];}
function locale_locales__getSetGlobalLocale(key,values){var data;if(key){if(typeof values==='undefined'){data=locale_locales__getLocale(key);}
else{data=defineLocale(key,values);}
if(data){globalLocale=data;}}
return globalLocale._abbr;}
function defineLocale(name,values){if(values!==null){values.abbr=name;locales[name]=locales[name]||new Locale();locales[name].set(values);locale_locales__getSetGlobalLocale(name);return locales[name];}else{delete locales[name];return null;}}
function locale_locales__getLocale(key){var locale;if(key&&key._locale&&key._locale._abbr){key=key._locale._abbr;}
if(!key){return globalLocale;}
if(!isArray(key)){locale=loadLocale(key);if(locale){return locale;}
key=[key];}
return chooseLocale(key);}
var aliases={};function addUnitAlias(unit,shorthand){var lowerCase=unit.toLowerCase();aliases[lowerCase]=aliases[lowerCase+'s']=aliases[shorthand]=unit;}
function normalizeUnits(units){return typeof units==='string'?aliases[units]||aliases[units.toLowerCase()]:undefined;}
function normalizeObjectUnits(inputObject){var normalizedInput={},normalizedProp,prop;for(prop in inputObject){if(hasOwnProp(inputObject,prop)){normalizedProp=normalizeUnits(prop);if(normalizedProp){normalizedInput[normalizedProp]=inputObject[prop];}}}
return normalizedInput;}
function makeGetSet(unit,keepTime){return function(value){if(value!=null){get_set__set(this,unit,value);utils_hooks__hooks.updateOffset(this,keepTime);return this;}else{return get_set__get(this,unit);}};}
function get_set__get(mom,unit){return mom._d['get'+(mom._isUTC?'UTC':'')+unit]();}
function get_set__set(mom,unit,value){return mom._d['set'+(mom._isUTC?'UTC':'')+unit](value);}
function getSet(units,value){var unit;if(typeof units==='object'){for(unit in units){this.set(unit,units[unit]);}}else{units=normalizeUnits(units);if(typeof this[units]==='function'){return this[units](value);}}
return this;}
function zeroFill(number,targetLength,forceSign){var absNumber=''+Math.abs(number),zerosToFill=targetLength-absNumber.length,sign=number>=0;return(sign?(forceSign?'+':''):'-')+
Math.pow(10,Math.max(0,zerosToFill)).toString().substr(1)+absNumber;}
var formattingTokens=/(\[[^\[]*\])|(\\)?(Mo|MM?M?M?|Do|DDDo|DD?D?D?|ddd?d?|do?|w[o|w]?|W[o|W]?|Q|YYYYYY|YYYYY|YYYY|YY|gg(ggg?)?|GG(GGG?)?|e|E|a|A|hh?|HH?|mm?|ss?|S{1,9}|x|X|zz?|ZZ?|.)/g;var localFormattingTokens=/(\[[^\[]*\])|(\\)?(LTS|LT|LL?L?L?|l{1,4})/g;var formatFunctions={};var formatTokenFunctions={};function addFormatToken(token,padded,ordinal,callback){var func=callback;if(typeof callback==='string'){func=function(){return this[callback]();};}
if(token){formatTokenFunctions[token]=func;}
if(padded){formatTokenFunctions[padded[0]]=function(){return zeroFill(func.apply(this,arguments),padded[1],padded[2]);};}
if(ordinal){formatTokenFunctions[ordinal]=function(){return this.localeData().ordinal(func.apply(this,arguments),token);};}}
function removeFormattingTokens(input){if(input.match(/\[[\s\S]/)){return input.replace(/^\[|\]$/g,'');}
return input.replace(/\\/g,'');}
function makeFormatFunction(format){var array=format.match(formattingTokens),i,length;for(i=0,length=array.length;i<length;i++){if(formatTokenFunctions[array[i]]){array[i]=formatTokenFunctions[array[i]];}else{array[i]=removeFormattingTokens(array[i]);}}
return function(mom){var output='';for(i=0;i<length;i++){output+=array[i]instanceof Function?array[i].call(mom,format):array[i];}
return output;};}
function formatMoment(m,format){if(!m.isValid()){return m.localeData().invalidDate();}
format=expandFormat(format,m.localeData());formatFunctions[format]=formatFunctions[format]||makeFormatFunction(format);return formatFunctions[format](m);}
function expandFormat(format,locale){var i=5;function replaceLongDateFormatTokens(input){return locale.longDateFormat(input)||input;}
localFormattingTokens.lastIndex=0;while(i>=0&&localFormattingTokens.test(format)){format=format.replace(localFormattingTokens,replaceLongDateFormatTokens);localFormattingTokens.lastIndex=0;i-=1;}
return format;}
var match1=/\d/;var match2=/\d\d/;var match3=/\d{3}/;var match4=/\d{4}/;var match6=/[+-]?\d{6}/;var match1to2=/\d\d?/;var match1to3=/\d{1,3}/;var match1to4=/\d{1,4}/;var match1to6=/[+-]?\d{1,6}/;var matchUnsigned=/\d+/;var matchSigned=/[+-]?\d+/;var matchOffset=/Z|[+-]\d\d:?\d\d/gi;var matchTimestamp=/[+-]?\d+(\.\d{1,3})?/;var matchWord=/[0-9]*['a-z\u00A0-\u05FF\u0700-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+|[\u0600-\u06FF\/]+(\s*?[\u0600-\u06FF]+){1,2}/i;var regexes={};function isFunction(sth){return typeof sth==='function'&&Object.prototype.toString.call(sth)==='[object Function]';}
function addRegexToken(token,regex,strictRegex){regexes[token]=isFunction(regex)?regex:function(isStrict){return(isStrict&&strictRegex)?strictRegex:regex;};}
function getParseRegexForToken(token,config){if(!hasOwnProp(regexes,token)){return new RegExp(unescapeFormat(token));}
return regexes[token](config._strict,config._locale);}
function unescapeFormat(s){return s.replace('\\','').replace(/\\(\[)|\\(\])|\[([^\]\[]*)\]|\\(.)/g,function(matched,p1,p2,p3,p4){return p1||p2||p3||p4;}).replace(/[-\/\\^$*+?.()|[\]{}]/g,'\\$&');}
var tokens={};function addParseToken(token,callback){var i,func=callback;if(typeof token==='string'){token=[token];}
if(typeof callback==='number'){func=function(input,array){array[callback]=toInt(input);};}
for(i=0;i<token.length;i++){tokens[token[i]]=func;}}
function addWeekParseToken(token,callback){addParseToken(token,function(input,array,config,token){config._w=config._w||{};callback(input,config._w,config,token);});}
function addTimeToArrayFromToken(token,input,config){if(input!=null&&hasOwnProp(tokens,token)){tokens[token](input,config._a,config,token);}}
var YEAR=0;var MONTH=1;var DATE=2;var HOUR=3;var MINUTE=4;var SECOND=5;var MILLISECOND=6;function daysInMonth(year,month){return new Date(Date.UTC(year,month+1,0)).getUTCDate();}
addFormatToken('M',['MM',2],'Mo',function(){return this.month()+1;});addFormatToken('MMM',0,0,function(format){return this.localeData().monthsShort(this,format);});addFormatToken('MMMM',0,0,function(format){return this.localeData().months(this,format);});addUnitAlias('month','M');addRegexToken('M',match1to2);addRegexToken('MM',match1to2,match2);addRegexToken('MMM',matchWord);addRegexToken('MMMM',matchWord);addParseToken(['M','MM'],function(input,array){array[MONTH]=toInt(input)-1;});addParseToken(['MMM','MMMM'],function(input,array,config,token){var month=config._locale.monthsParse(input,token,config._strict);if(month!=null){array[MONTH]=month;}else{getParsingFlags(config).invalidMonth=input;}});var defaultLocaleMonths='Janvier_Février_Mars_Avril_Mai_Juin_Juillet_Août_Septembre_Octobre_Novembre_Decembre'.split('_');function localeMonths(m){return this._months[m.month()];}
var defaultLocaleMonthsShort='Jan_Fev_Mars_Avr_Mai_Juin_Juil_Août_Sep_Oct_Nov_Dec'.split('_');function localeMonthsShort(m){return this._monthsShort[m.month()];}
function localeMonthsParse(monthName,format,strict){var i,mom,regex;if(!this._monthsParse){this._monthsParse=[];this._longMonthsParse=[];this._shortMonthsParse=[];}
for(i=0;i<12;i++){mom=create_utc__createUTC([2000,i]);if(strict&&!this._longMonthsParse[i]){this._longMonthsParse[i]=new RegExp('^'+this.months(mom,'').replace('.','')+'$','i');this._shortMonthsParse[i]=new RegExp('^'+this.monthsShort(mom,'').replace('.','')+'$','i');}
if(!strict&&!this._monthsParse[i]){regex='^'+this.months(mom,'')+'|^'+this.monthsShort(mom,'');this._monthsParse[i]=new RegExp(regex.replace('.',''),'i');}
if(strict&&format==='MMMM'&&this._longMonthsParse[i].test(monthName)){return i;}else if(strict&&format==='MMM'&&this._shortMonthsParse[i].test(monthName)){return i;}else if(!strict&&this._monthsParse[i].test(monthName)){return i;}}}
function setMonth(mom,value){var dayOfMonth;if(typeof value==='string'){value=mom.localeData().monthsParse(value);if(typeof value!=='number'){return mom;}}
dayOfMonth=Math.min(mom.date(),daysInMonth(mom.year(),value));mom._d['set'+(mom._isUTC?'UTC':'')+'Month'](value,dayOfMonth);return mom;}
function getSetMonth(value){if(value!=null){setMonth(this,value);utils_hooks__hooks.updateOffset(this,true);return this;}else{return get_set__get(this,'Month');}}
function getDaysInMonth(){return daysInMonth(this.year(),this.month());}
function checkOverflow(m){var overflow;var a=m._a;if(a&&getParsingFlags(m).overflow===-2){overflow=a[MONTH]<0||a[MONTH]>11?MONTH:a[DATE]<1||a[DATE]>daysInMonth(a[YEAR],a[MONTH])?DATE:a[HOUR]<0||a[HOUR]>24||(a[HOUR]===24&&(a[MINUTE]!==0||a[SECOND]!==0||a[MILLISECOND]!==0))?HOUR:a[MINUTE]<0||a[MINUTE]>59?MINUTE:a[SECOND]<0||a[SECOND]>59?SECOND:a[MILLISECOND]<0||a[MILLISECOND]>999?MILLISECOND:-1;if(getParsingFlags(m)._overflowDayOfYear&&(overflow<YEAR||overflow>DATE)){overflow=DATE;}
getParsingFlags(m).overflow=overflow;}
return m;}
function warn(msg){if(utils_hooks__hooks.suppressDeprecationWarnings===false&&typeof console!=='undefined'&&console.warn){console.warn('Deprecation warning: '+msg);}}
function deprecate(msg,fn){var firstTime=true;return extend(function(){if(firstTime){warn(msg+'\n'+(new Error()).stack);firstTime=false;}
return fn.apply(this,arguments);},fn);}
var deprecations={};function deprecateSimple(name,msg){if(!deprecations[name]){warn(msg);deprecations[name]=true;}}
utils_hooks__hooks.suppressDeprecationWarnings=false;var from_string__isoRegex=/^\s*(?:[+-]\d{6}|\d{4})-(?:(\d\d-\d\d)|(W\d\d$)|(W\d\d-\d)|(\d\d\d))((T| )(\d\d(:\d\d(:\d\d(\.\d+)?)?)?)?([\+\-]\d\d(?::?\d\d)?|\s*Z)?)?$/;var isoDates=[['YYYYYY-MM-DD',/[+-]\d{6}-\d{2}-\d{2}/],['YYYY-MM-DD',/\d{4}-\d{2}-\d{2}/],['GGGG-[W]WW-E',/\d{4}-W\d{2}-\d/],['GGGG-[W]WW',/\d{4}-W\d{2}/],['YYYY-DDD',/\d{4}-\d{3}/]];var isoTimes=[['HH:mm:ss.SSSS',/(T| )\d\d:\d\d:\d\d\.\d+/],['HH:mm:ss',/(T| )\d\d:\d\d:\d\d/],['HH:mm',/(T| )\d\d:\d\d/],['HH',/(T| )\d\d/]];var aspNetJsonRegex=/^\/?Date\((\-?\d+)/i;function configFromISO(config){var i,l,string=config._i,match=from_string__isoRegex.exec(string);if(match){getParsingFlags(config).iso=true;for(i=0,l=isoDates.length;i<l;i++){if(isoDates[i][1].exec(string)){config._f=isoDates[i][0];break;}}
for(i=0,l=isoTimes.length;i<l;i++){if(isoTimes[i][1].exec(string)){config._f+=(match[6]||' ')+isoTimes[i][0];break;}}
if(string.match(matchOffset)){config._f+='Z';}
configFromStringAndFormat(config);}else{config._isValid=false;}}
function configFromString(config){var matched=aspNetJsonRegex.exec(config._i);if(matched!==null){config._d=new Date(+matched[1]);return;}
configFromISO(config);if(config._isValid===false){delete config._isValid;utils_hooks__hooks.createFromInputFallback(config);}}
utils_hooks__hooks.createFromInputFallback=deprecate('moment construction falls back to js Date. This is '+
'discouraged and will be removed in upcoming major '+
'release. Please refer to '+
'https://github.com/moment/moment/issues/1407 for more info.',function(config){config._d=new Date(config._i+(config._useUTC?' UTC':''));});function createDate(y,m,d,h,M,s,ms){var date=new Date(y,m,d,h,M,s,ms);if(y<1970){date.setFullYear(y);}
return date;}
function createUTCDate(y){var date=new Date(Date.UTC.apply(null,arguments));if(y<1970){date.setUTCFullYear(y);}
return date;}
addFormatToken(0,['YY',2],0,function(){return this.year()%100;});addFormatToken(0,['YYYY',4],0,'year');addFormatToken(0,['YYYYY',5],0,'year');addFormatToken(0,['YYYYYY',6,true],0,'year');addUnitAlias('year','y');addRegexToken('Y',matchSigned);addRegexToken('YY',match1to2,match2);addRegexToken('YYYY',match1to4,match4);addRegexToken('YYYYY',match1to6,match6);addRegexToken('YYYYYY',match1to6,match6);addParseToken(['YYYYY','YYYYYY'],YEAR);addParseToken('YYYY',function(input,array){array[YEAR]=input.length===2?utils_hooks__hooks.parseTwoDigitYear(input):toInt(input);});addParseToken('YY',function(input,array){array[YEAR]=utils_hooks__hooks.parseTwoDigitYear(input);});function daysInYear(year){return isLeapYear(year)?366:365;}
function isLeapYear(year){return(year%4===0&&year%100!==0)||year%400===0;}
utils_hooks__hooks.parseTwoDigitYear=function(input){return toInt(input)+(toInt(input)>68?1900:2000);};var getSetYear=makeGetSet('FullYear',false);function getIsLeapYear(){return isLeapYear(this.year());}
addFormatToken('w',['ww',2],'wo','week');addFormatToken('W',['WW',2],'Wo','isoWeek');addUnitAlias('week','w');addUnitAlias('isoWeek','W');addRegexToken('w',match1to2);addRegexToken('ww',match1to2,match2);addRegexToken('W',match1to2);addRegexToken('WW',match1to2,match2);addWeekParseToken(['w','ww','W','WW'],function(input,week,config,token){week[token.substr(0,1)]=toInt(input);});function weekOfYear(mom,firstDayOfWeek,firstDayOfWeekOfYear){var end=firstDayOfWeekOfYear-firstDayOfWeek,daysToDayOfWeek=firstDayOfWeekOfYear-mom.day(),adjustedMoment;if(daysToDayOfWeek>end){daysToDayOfWeek-=7;}
if(daysToDayOfWeek<end-7){daysToDayOfWeek+=7;}
adjustedMoment=local__createLocal(mom).add(daysToDayOfWeek,'d');return{week:Math.ceil(adjustedMoment.dayOfYear()/7),year:adjustedMoment.year()};}
function localeWeek(mom){return weekOfYear(mom,this._week.dow,this._week.doy).week;}
var defaultLocaleWeek={dow:0,doy:6};function localeFirstDayOfWeek(){return this._week.dow;}
function localeFirstDayOfYear(){return this._week.doy;}
function getSetWeek(input){var week=this.localeData().week(this);return input==null?week:this.add((input-week)*7,'d');}
function getSetISOWeek(input){var week=weekOfYear(this,1,4).week;return input==null?week:this.add((input-week)*7,'d');}
addFormatToken('DDD',['DDDD',3],'DDDo','dayOfYear');addUnitAlias('dayOfYear','DDD');addRegexToken('DDD',match1to3);addRegexToken('DDDD',match3);addParseToken(['DDD','DDDD'],function(input,array,config){config._dayOfYear=toInt(input);});function dayOfYearFromWeeks(year,week,weekday,firstDayOfWeekOfYear,firstDayOfWeek){var week1Jan=6+firstDayOfWeek-firstDayOfWeekOfYear,janX=createUTCDate(year,0,1+week1Jan),d=janX.getUTCDay(),dayOfYear;if(d<firstDayOfWeek){d+=7;}
weekday=weekday!=null?1*weekday:firstDayOfWeek;dayOfYear=1+week1Jan+7*(week-1)-d+weekday;return{year:dayOfYear>0?year:year-1,dayOfYear:dayOfYear>0?dayOfYear:daysInYear(year-1)+dayOfYear};}
function getSetDayOfYear(input){var dayOfYear=Math.round((this.clone().startOf('day')-this.clone().startOf('year'))/864e5)+1;return input==null?dayOfYear:this.add((input-dayOfYear),'d');}
function defaults(a,b,c){if(a!=null){return a;}
if(b!=null){return b;}
return c;}
function currentDateArray(config){var now=new Date();if(config._useUTC){return[now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()];}
return[now.getFullYear(),now.getMonth(),now.getDate()];}
function configFromArray(config){var i,date,input=[],currentDate,yearToUse;if(config._d){return;}
currentDate=currentDateArray(config);if(config._w&&config._a[DATE]==null&&config._a[MONTH]==null){dayOfYearFromWeekInfo(config);}
if(config._dayOfYear){yearToUse=defaults(config._a[YEAR],currentDate[YEAR]);if(config._dayOfYear>daysInYear(yearToUse)){getParsingFlags(config)._overflowDayOfYear=true;}
date=createUTCDate(yearToUse,0,config._dayOfYear);config._a[MONTH]=date.getUTCMonth();config._a[DATE]=date.getUTCDate();}
for(i=0;i<3&&config._a[i]==null;++i){config._a[i]=input[i]=currentDate[i];}
for(;i<7;i++){config._a[i]=input[i]=(config._a[i]==null)?(i===2?1:0):config._a[i];}
if(config._a[HOUR]===24&&config._a[MINUTE]===0&&config._a[SECOND]===0&&config._a[MILLISECOND]===0){config._nextDay=true;config._a[HOUR]=0;}
config._d=(config._useUTC?createUTCDate:createDate).apply(null,input);if(config._tzm!=null){config._d.setUTCMinutes(config._d.getUTCMinutes()-config._tzm);}
if(config._nextDay){config._a[HOUR]=24;}}
function dayOfYearFromWeekInfo(config){var w,weekYear,week,weekday,dow,doy,temp;w=config._w;if(w.GG!=null||w.W!=null||w.E!=null){dow=1;doy=4;weekYear=defaults(w.GG,config._a[YEAR],weekOfYear(local__createLocal(),1,4).year);week=defaults(w.W,1);weekday=defaults(w.E,1);}else{dow=config._locale._week.dow;doy=config._locale._week.doy;weekYear=defaults(w.gg,config._a[YEAR],weekOfYear(local__createLocal(),dow,doy).year);week=defaults(w.w,1);if(w.d!=null){weekday=w.d;if(weekday<dow){++week;}}else if(w.e!=null){weekday=w.e+dow;}else{weekday=dow;}}
temp=dayOfYearFromWeeks(weekYear,week,weekday,doy,dow);config._a[YEAR]=temp.year;config._dayOfYear=temp.dayOfYear;}
utils_hooks__hooks.ISO_8601=function(){};function configFromStringAndFormat(config){if(config._f===utils_hooks__hooks.ISO_8601){configFromISO(config);return;}
config._a=[];getParsingFlags(config).empty=true;var string=''+config._i,i,parsedInput,tokens,token,skipped,stringLength=string.length,totalParsedInputLength=0;tokens=expandFormat(config._f,config._locale).match(formattingTokens)||[];for(i=0;i<tokens.length;i++){token=tokens[i];parsedInput=(string.match(getParseRegexForToken(token,config))||[])[0];if(parsedInput){skipped=string.substr(0,string.indexOf(parsedInput));if(skipped.length>0){getParsingFlags(config).unusedInput.push(skipped);}
string=string.slice(string.indexOf(parsedInput)+parsedInput.length);totalParsedInputLength+=parsedInput.length;}
if(formatTokenFunctions[token]){if(parsedInput){getParsingFlags(config).empty=false;}
else{getParsingFlags(config).unusedTokens.push(token);}
addTimeToArrayFromToken(token,parsedInput,config);}
else if(config._strict&&!parsedInput){getParsingFlags(config).unusedTokens.push(token);}}
getParsingFlags(config).charsLeftOver=stringLength-totalParsedInputLength;if(string.length>0){getParsingFlags(config).unusedInput.push(string);}
if(getParsingFlags(config).bigHour===true&&config._a[HOUR]<=12&&config._a[HOUR]>0){getParsingFlags(config).bigHour=undefined;}
config._a[HOUR]=meridiemFixWrap(config._locale,config._a[HOUR],config._meridiem);configFromArray(config);checkOverflow(config);}
function meridiemFixWrap(locale,hour,meridiem){var isPm;if(meridiem==null){return hour;}
if(locale.meridiemHour!=null){return locale.meridiemHour(hour,meridiem);}else if(locale.isPM!=null){isPm=locale.isPM(meridiem);if(isPm&&hour<12){hour+=12;}
if(!isPm&&hour===12){hour=0;}
return hour;}else{return hour;}}
function configFromStringAndArray(config){var tempConfig,bestMoment,scoreToBeat,i,currentScore;if(config._f.length===0){getParsingFlags(config).invalidFormat=true;config._d=new Date(NaN);return;}
for(i=0;i<config._f.length;i++){currentScore=0;tempConfig=copyConfig({},config);if(config._useUTC!=null){tempConfig._useUTC=config._useUTC;}
tempConfig._f=config._f[i];configFromStringAndFormat(tempConfig);if(!valid__isValid(tempConfig)){continue;}
currentScore+=getParsingFlags(tempConfig).charsLeftOver;currentScore+=getParsingFlags(tempConfig).unusedTokens.length*10;getParsingFlags(tempConfig).score=currentScore;if(scoreToBeat==null||currentScore<scoreToBeat){scoreToBeat=currentScore;bestMoment=tempConfig;}}
extend(config,bestMoment||tempConfig);}
function configFromObject(config){if(config._d){return;}
var i=normalizeObjectUnits(config._i);config._a=[i.year,i.month,i.day||i.date,i.hour,i.minute,i.second,i.millisecond];configFromArray(config);}
function createFromConfig(config){var res=new Moment(checkOverflow(prepareConfig(config)));if(res._nextDay){res.add(1,'d');res._nextDay=undefined;}
return res;}
function prepareConfig(config){var input=config._i,format=config._f;config._locale=config._locale||locale_locales__getLocale(config._l);if(input===null||(format===undefined&&input==='')){return valid__createInvalid({nullInput:true});}
if(typeof input==='string'){config._i=input=config._locale.preparse(input);}
if(isMoment(input)){return new Moment(checkOverflow(input));}else if(isArray(format)){configFromStringAndArray(config);}else if(format){configFromStringAndFormat(config);}else if(isDate(input)){config._d=input;}else{configFromInput(config);}
return config;}
function configFromInput(config){var input=config._i;if(input===undefined){config._d=new Date();}else if(isDate(input)){config._d=new Date(+input);}else if(typeof input==='string'){configFromString(config);}else if(isArray(input)){config._a=map(input.slice(0),function(obj){return parseInt(obj,10);});configFromArray(config);}else if(typeof(input)==='object'){configFromObject(config);}else if(typeof(input)==='number'){config._d=new Date(input);}else{utils_hooks__hooks.createFromInputFallback(config);}}
function createLocalOrUTC(input,format,locale,strict,isUTC){var c={};if(typeof(locale)==='boolean'){strict=locale;locale=undefined;}
c._isAMomentObject=true;c._useUTC=c._isUTC=isUTC;c._l=locale;c._i=input;c._f=format;c._strict=strict;return createFromConfig(c);}
function local__createLocal(input,format,locale,strict){return createLocalOrUTC(input,format,locale,strict,false);}
var prototypeMin=deprecate('moment().min is deprecated, use moment.min instead. https://github.com/moment/moment/issues/1548',function(){var other=local__createLocal.apply(null,arguments);return other<this?this:other;});var prototypeMax=deprecate('moment().max is deprecated, use moment.max instead. https://github.com/moment/moment/issues/1548',function(){var other=local__createLocal.apply(null,arguments);return other>this?this:other;});function pickBy(fn,moments){var res,i;if(moments.length===1&&isArray(moments[0])){moments=moments[0];}
if(!moments.length){return local__createLocal();}
res=moments[0];for(i=1;i<moments.length;++i){if(!moments[i].isValid()||moments[i][fn](res)){res=moments[i];}}
return res;}
function min(){var args=[].slice.call(arguments,0);return pickBy('isBefore',args);}
function max(){var args=[].slice.call(arguments,0);return pickBy('isAfter',args);}
function Duration(duration){var normalizedInput=normalizeObjectUnits(duration),years=normalizedInput.year||0,quarters=normalizedInput.quarter||0,months=normalizedInput.month||0,weeks=normalizedInput.week||0,days=normalizedInput.day||0,hours=normalizedInput.hour||0,minutes=normalizedInput.minute||0,seconds=normalizedInput.second||0,milliseconds=normalizedInput.millisecond||0;this._milliseconds=+milliseconds+
seconds*1e3+
minutes*6e4+
hours*36e5;this._days=+days+
weeks*7;this._months=+months+
quarters*3+
years*12;this._data={};this._locale=locale_locales__getLocale();this._bubble();}
function isDuration(obj){return obj instanceof Duration;}
function offset(token,separator){addFormatToken(token,0,0,function(){var offset=this.utcOffset();var sign='+';if(offset<0){offset=-offset;sign='-';}
return sign+zeroFill(~~(offset/60),2)+separator+zeroFill(~~(offset)%60,2);});}
offset('Z',':');offset('ZZ','');addRegexToken('Z',matchOffset);addRegexToken('ZZ',matchOffset);addParseToken(['Z','ZZ'],function(input,array,config){config._useUTC=true;config._tzm=offsetFromString(input);});var chunkOffset=/([\+\-]|\d\d)/gi;function offsetFromString(string){var matches=((string||'').match(matchOffset)||[]);var chunk=matches[matches.length-1]||[];var parts=(chunk+'').match(chunkOffset)||['-',0,0];var minutes=+(parts[1]*60)+toInt(parts[2]);return parts[0]==='+'?minutes:-minutes;}
function cloneWithOffset(input,model){var res,diff;if(model._isUTC){res=model.clone();diff=(isMoment(input)||isDate(input)?+input:+local__createLocal(input))-(+res);res._d.setTime(+res._d+diff);utils_hooks__hooks.updateOffset(res,false);return res;}else{return local__createLocal(input).local();}}
function getDateOffset(m){return-Math.round(m._d.getTimezoneOffset()/15)*15;}
utils_hooks__hooks.updateOffset=function(){};function getSetOffset(input,keepLocalTime){var offset=this._offset||0,localAdjust;if(input!=null){if(typeof input==='string'){input=offsetFromString(input);}
if(Math.abs(input)<16){input=input*60;}
if(!this._isUTC&&keepLocalTime){localAdjust=getDateOffset(this);}
this._offset=input;this._isUTC=true;if(localAdjust!=null){this.add(localAdjust,'m');}
if(offset!==input){if(!keepLocalTime||this._changeInProgress){add_subtract__addSubtract(this,create__createDuration(input-offset,'m'),1,false);}else if(!this._changeInProgress){this._changeInProgress=true;utils_hooks__hooks.updateOffset(this,true);this._changeInProgress=null;}}
return this;}else{return this._isUTC?offset:getDateOffset(this);}}
function getSetZone(input,keepLocalTime){if(input!=null){if(typeof input!=='string'){input=-input;}
this.utcOffset(input,keepLocalTime);return this;}else{return-this.utcOffset();}}
function setOffsetToUTC(keepLocalTime){return this.utcOffset(0,keepLocalTime);}
function setOffsetToLocal(keepLocalTime){if(this._isUTC){this.utcOffset(0,keepLocalTime);this._isUTC=false;if(keepLocalTime){this.subtract(getDateOffset(this),'m');}}
return this;}
function setOffsetToParsedOffset(){if(this._tzm){this.utcOffset(this._tzm);}else if(typeof this._i==='string'){this.utcOffset(offsetFromString(this._i));}
return this;}
function hasAlignedHourOffset(input){input=input?local__createLocal(input).utcOffset():0;return(this.utcOffset()-input)%60===0;}
function isDaylightSavingTime(){return(this.utcOffset()>this.clone().month(0).utcOffset()||this.utcOffset()>this.clone().month(5).utcOffset());}
function isDaylightSavingTimeShifted(){if(typeof this._isDSTShifted!=='undefined'){return this._isDSTShifted;}
var c={};copyConfig(c,this);c=prepareConfig(c);if(c._a){var other=c._isUTC?create_utc__createUTC(c._a):local__createLocal(c._a);this._isDSTShifted=this.isValid()&&compareArrays(c._a,other.toArray())>0;}else{this._isDSTShifted=false;}
return this._isDSTShifted;}
function isLocal(){return!this._isUTC;}
function isUtcOffset(){return this._isUTC;}
function isUtc(){return this._isUTC&&this._offset===0;}
var aspNetRegex=/(\-)?(?:(\d*)\.)?(\d+)\:(\d+)(?:\:(\d+)\.?(\d{3})?)?/;var create__isoRegex=/^(-)?P(?:(?:([0-9,.]*)Y)?(?:([0-9,.]*)M)?(?:([0-9,.]*)D)?(?:T(?:([0-9,.]*)H)?(?:([0-9,.]*)M)?(?:([0-9,.]*)S)?)?|([0-9,.]*)W)$/;function create__createDuration(input,key){var duration=input,match=null,sign,ret,diffRes;if(isDuration(input)){duration={ms:input._milliseconds,d:input._days,M:input._months};}else if(typeof input==='number'){duration={};if(key){duration[key]=input;}else{duration.milliseconds=input;}}else if(!!(match=aspNetRegex.exec(input))){sign=(match[1]==='-')?-1:1;duration={y:0,d:toInt(match[DATE])*sign,h:toInt(match[HOUR])*sign,m:toInt(match[MINUTE])*sign,s:toInt(match[SECOND])*sign,ms:toInt(match[MILLISECOND])*sign};}else if(!!(match=create__isoRegex.exec(input))){sign=(match[1]==='-')?-1:1;duration={y:parseIso(match[2],sign),M:parseIso(match[3],sign),d:parseIso(match[4],sign),h:parseIso(match[5],sign),m:parseIso(match[6],sign),s:parseIso(match[7],sign),w:parseIso(match[8],sign)};}else if(duration==null){duration={};}else if(typeof duration==='object'&&('from'in duration||'to'in duration)){diffRes=momentsDifference(local__createLocal(duration.from),local__createLocal(duration.to));duration={};duration.ms=diffRes.milliseconds;duration.M=diffRes.months;}
ret=new Duration(duration);if(isDuration(input)&&hasOwnProp(input,'_locale')){ret._locale=input._locale;}
return ret;}
create__createDuration.fn=Duration.prototype;function parseIso(inp,sign){var res=inp&&parseFloat(inp.replace(',','.'));return(isNaN(res)?0:res)*sign;}
function positiveMomentsDifference(base,other){var res={milliseconds:0,months:0};res.months=other.month()-base.month()+
(other.year()-base.year())*12;if(base.clone().add(res.months,'M').isAfter(other)){--res.months;}
res.milliseconds=+other-+(base.clone().add(res.months,'M'));return res;}
function momentsDifference(base,other){var res;other=cloneWithOffset(other,base);if(base.isBefore(other)){res=positiveMomentsDifference(base,other);}else{res=positiveMomentsDifference(other,base);res.milliseconds=-res.milliseconds;res.months=-res.months;}
return res;}
function createAdder(direction,name){return function(val,period){var dur,tmp;if(period!==null&&!isNaN(+period)){deprecateSimple(name,'moment().'+name+'(period, number) is deprecated. Please use moment().'+name+'(number, period).');tmp=val;val=period;period=tmp;}
val=typeof val==='string'?+val:val;dur=create__createDuration(val,period);add_subtract__addSubtract(this,dur,direction);return this;};}
function add_subtract__addSubtract(mom,duration,isAdding,updateOffset){var milliseconds=duration._milliseconds,days=duration._days,months=duration._months;updateOffset=updateOffset==null?true:updateOffset;if(milliseconds){mom._d.setTime(+mom._d+milliseconds*isAdding);}
if(days){get_set__set(mom,'Date',get_set__get(mom,'Date')+days*isAdding);}
if(months){setMonth(mom,get_set__get(mom,'Month')+months*isAdding);}
if(updateOffset){utils_hooks__hooks.updateOffset(mom,days||months);}}
var add_subtract__add=createAdder(1,'add');var add_subtract__subtract=createAdder(-1,'subtract');function moment_calendar__calendar(time,formats){var now=time||local__createLocal(),sod=cloneWithOffset(now,this).startOf('day'),diff=this.diff(sod,'days',true),format=diff<-6?'sameElse':diff<-1?'lastWeek':diff<0?'lastDay':diff<1?'sameDay':diff<2?'nextDay':diff<7?'nextWeek':'sameElse';return this.format(formats&&formats[format]||this.localeData().calendar(format,this,local__createLocal(now)));}
function clone(){return new Moment(this);}
function isAfter(input,units){var inputMs;units=normalizeUnits(typeof units!=='undefined'?units:'millisecond');if(units==='millisecond'){input=isMoment(input)?input:local__createLocal(input);return+this>+input;}else{inputMs=isMoment(input)?+input:+local__createLocal(input);return inputMs<+this.clone().startOf(units);}}
function isBefore(input,units){var inputMs;units=normalizeUnits(typeof units!=='undefined'?units:'millisecond');if(units==='millisecond'){input=isMoment(input)?input:local__createLocal(input);return+this<+input;}else{inputMs=isMoment(input)?+input:+local__createLocal(input);return+this.clone().endOf(units)<inputMs;}}
function isBetween(from,to,units){return this.isAfter(from,units)&&this.isBefore(to,units);}
function isSame(input,units){var inputMs;units=normalizeUnits(units||'millisecond');if(units==='millisecond'){input=isMoment(input)?input:local__createLocal(input);return+this===+input;}else{inputMs=+local__createLocal(input);return+(this.clone().startOf(units))<=inputMs&&inputMs<=+(this.clone().endOf(units));}}
function diff(input,units,asFloat){var that=cloneWithOffset(input,this),zoneDelta=(that.utcOffset()-this.utcOffset())*6e4,delta,output;units=normalizeUnits(units);if(units==='year'||units==='month'||units==='quarter'){output=monthDiff(this,that);if(units==='quarter'){output=output/3;}else if(units==='year'){output=output/12;}}else{delta=this-that;output=units==='second'?delta/1e3:units==='minute'?delta/6e4:units==='hour'?delta/36e5:units==='day'?(delta-zoneDelta)/864e5:units==='week'?(delta-zoneDelta)/6048e5:delta;}
return asFloat?output:absFloor(output);}
function monthDiff(a,b){var wholeMonthDiff=((b.year()-a.year())*12)+(b.month()-a.month()),anchor=a.clone().add(wholeMonthDiff,'months'),anchor2,adjust;if(b-anchor<0){anchor2=a.clone().add(wholeMonthDiff-1,'months');adjust=(b-anchor)/(anchor-anchor2);}else{anchor2=a.clone().add(wholeMonthDiff+1,'months');adjust=(b-anchor)/(anchor2-anchor);}
return-(wholeMonthDiff+adjust);}
utils_hooks__hooks.defaultFormat='YYYY-MM-DDTHH:mm:ssZ';function toString(){return this.clone().locale('en').format('ddd MMM DD YYYY HH:mm:ss [GMT]ZZ');}
function moment_format__toISOString(){var m=this.clone().utc();if(0<m.year()&&m.year()<=9999){if('function'===typeof Date.prototype.toISOString){return this.toDate().toISOString();}else{return formatMoment(m,'DD-MM-YYYY[T]HH:mm');}}else{return formatMoment(m,'DD-MM-YYYY[T]HH:mm');}}
function format(inputString){var output=formatMoment(this,inputString||utils_hooks__hooks.defaultFormat);return this.localeData().postformat(output);}
function from(time,withoutSuffix){if(!this.isValid()){return this.localeData().invalidDate();}
return create__createDuration({to:this,from:time}).locale(this.locale()).humanize(!withoutSuffix);}
function fromNow(withoutSuffix){return this.from(local__createLocal(),withoutSuffix);}
function to(time,withoutSuffix){if(!this.isValid()){return this.localeData().invalidDate();}
return create__createDuration({from:this,to:time}).locale(this.locale()).humanize(!withoutSuffix);}
function toNow(withoutSuffix){return this.to(local__createLocal(),withoutSuffix);}
function locale(key){var newLocaleData;if(key===undefined){return this._locale._abbr;}else{newLocaleData=locale_locales__getLocale(key);if(newLocaleData!=null){this._locale=newLocaleData;}
return this;}}
var lang=deprecate('moment().lang() is deprecated. Instead, use moment().localeData() to get the language configuration. Use moment().locale() to change languages.',function(key){if(key===undefined){return this.localeData();}else{return this.locale(key);}});function localeData(){return this._locale;}
function startOf(units){units=normalizeUnits(units);switch(units){case 'year':this.month(0);case 'quarter':case 'month':this.date(1);case 'week':case 'isoWeek':case 'day':this.hours(0);case 'hour':this.minutes(0);case 'minute':this.seconds(0);case 'second':this.milliseconds(0);}
if(units==='week'){this.weekday(0);}
if(units==='isoWeek'){this.isoWeekday(1);}
if(units==='quarter'){this.month(Math.floor(this.month()/3)*3);}
return this;}
function endOf(units){units=normalizeUnits(units);if(units===undefined||units==='millisecond'){return this;}
return this.startOf(units).add(1,(units==='isoWeek'?'week':units)).subtract(1,'ms');}
function to_type__valueOf(){return+this._d-((this._offset||0)*60000);}
function unix(){return Math.floor(+this/1000);}
function toDate(){return this._offset?new Date(+this):this._d;}
function toArray(){var m=this;return[m.year(),m.month(),m.date(),m.hour(),m.minute(),m.second(),m.millisecond()];}
function toObject(){var m=this;return{years:m.year(),months:m.month(),date:m.date(),hours:m.hours(),minutes:m.minutes(),seconds:m.seconds(),milliseconds:m.milliseconds()};}
function moment_valid__isValid(){return valid__isValid(this);}
function parsingFlags(){return extend({},getParsingFlags(this));}
function invalidAt(){return getParsingFlags(this).overflow;}
addFormatToken(0,['gg',2],0,function(){return this.weekYear()%100;});addFormatToken(0,['GG',2],0,function(){return this.isoWeekYear()%100;});function addWeekYearFormatToken(token,getter){addFormatToken(0,[token,token.length],0,getter);}
addWeekYearFormatToken('gggg','weekYear');addWeekYearFormatToken('ggggg','weekYear');addWeekYearFormatToken('GGGG','isoWeekYear');addWeekYearFormatToken('GGGGG','isoWeekYear');addUnitAlias('weekYear','gg');addUnitAlias('isoWeekYear','GG');addRegexToken('G',matchSigned);addRegexToken('g',matchSigned);addRegexToken('GG',match1to2,match2);addRegexToken('gg',match1to2,match2);addRegexToken('GGGG',match1to4,match4);addRegexToken('gggg',match1to4,match4);addRegexToken('GGGGG',match1to6,match6);addRegexToken('ggggg',match1to6,match6);addWeekParseToken(['gggg','ggggg','GGGG','GGGGG'],function(input,week,config,token){week[token.substr(0,2)]=toInt(input);});addWeekParseToken(['gg','GG'],function(input,week,config,token){week[token]=utils_hooks__hooks.parseTwoDigitYear(input);});function weeksInYear(year,dow,doy){return weekOfYear(local__createLocal([year,11,31+dow-doy]),dow,doy).week;}
function getSetWeekYear(input){var year=weekOfYear(this,this.localeData()._week.dow,this.localeData()._week.doy).year;return input==null?year:this.add((input-year),'y');}
function getSetISOWeekYear(input){var year=weekOfYear(this,1,4).year;return input==null?year:this.add((input-year),'y');}
function getISOWeeksInYear(){return weeksInYear(this.year(),1,4);}
function getWeeksInYear(){var weekInfo=this.localeData()._week;return weeksInYear(this.year(),weekInfo.dow,weekInfo.doy);}
addFormatToken('Q',0,0,'quarter');addUnitAlias('quarter','Q');addRegexToken('Q',match1);addParseToken('Q',function(input,array){array[MONTH]=(toInt(input)-1)*3;});function getSetQuarter(input){return input==null?Math.ceil((this.month()+1)/3):this.month((input-1)*3+this.month()%3);}
addFormatToken('D',['DD',2],'Do','date');addUnitAlias('date','D');addRegexToken('D',match1to2);addRegexToken('DD',match1to2,match2);addRegexToken('Do',function(isStrict,locale){return isStrict?locale._ordinalParse:locale._ordinalParseLenient;});addParseToken(['D','DD'],DATE);addParseToken('Do',function(input,array){array[DATE]=toInt(input.match(match1to2)[0],10);});var getSetDayOfMonth=makeGetSet('Date',true);addFormatToken('d',0,'do','day');addFormatToken('dd',0,0,function(format){return this.localeData().weekdaysMin(this,format);});addFormatToken('ddd',0,0,function(format){return this.localeData().weekdaysShort(this,format);});addFormatToken('dddd',0,0,function(format){return this.localeData().weekdays(this,format);});addFormatToken('e',0,0,'weekday');addFormatToken('E',0,0,'isoWeekday');addUnitAlias('day','d');addUnitAlias('weekday','e');addUnitAlias('isoWeekday','E');addRegexToken('d',match1to2);addRegexToken('e',match1to2);addRegexToken('E',match1to2);addRegexToken('dd',matchWord);addRegexToken('ddd',matchWord);addRegexToken('dddd',matchWord);addWeekParseToken(['dd','ddd','dddd'],function(input,week,config){var weekday=config._locale.weekdaysParse(input);if(weekday!=null){week.d=weekday;}else{getParsingFlags(config).invalidWeekday=input;}});addWeekParseToken(['d','e','E'],function(input,week,config,token){week[token]=toInt(input);});function parseWeekday(input,locale){if(typeof input!=='string'){return input;}
if(!isNaN(input)){return parseInt(input,10);}
input=locale.weekdaysParse(input);if(typeof input==='number'){return input;}
return null;}
var defaultLocaleWeekdays='Dimanche_Lundi_Mardi_Mercredi_Jeudi_Vendredi_Samedi'.split('_');function localeWeekdays(m){return this._weekdays[m.day()];}
var defaultLocaleWeekdaysShort='Lun_Mar_Tue_Mer_Jeu_Ven_Sam'.split('_');function localeWeekdaysShort(m){return this._weekdaysShort[m.day()];}
var defaultLocaleWeekdaysMin='Lu_Ma_Tu_Me_Je_Ve_Sa'.split('_');function localeWeekdaysMin(m){return this._weekdaysMin[m.day()];}
function localeWeekdaysParse(weekdayName){var i,mom,regex;this._weekdaysParse=this._weekdaysParse||[];for(i=0;i<7;i++){if(!this._weekdaysParse[i]){mom=local__createLocal([2000,1]).day(i);regex='^'+this.weekdays(mom,'')+'|^'+this.weekdaysShort(mom,'')+'|^'+this.weekdaysMin(mom,'');this._weekdaysParse[i]=new RegExp(regex.replace('.',''),'i');}
if(this._weekdaysParse[i].test(weekdayName)){return i;}}}
function getSetDayOfWeek(input){var day=this._isUTC?this._d.getUTCDay():this._d.getDay();if(input!=null){input=parseWeekday(input,this.localeData());return this.add(input-day,'d');}else{return day;}}
function getSetLocaleDayOfWeek(input){var weekday=(this.day()+7-this.localeData()._week.dow)%7;return input==null?weekday:this.add(input-weekday,'d');}
function getSetISODayOfWeek(input){return input==null?this.day()||7:this.day(this.day()%7?input:input-7);}
addFormatToken('H',['HH',2],0,'hour');addFormatToken('h',['hh',2],0,function(){return this.hours()%12||12;});function meridiem(token,lowercase){addFormatToken(token,0,0,function(){return this.localeData().meridiem(this.hours(),this.minutes(),lowercase);});}
meridiem('a',true);meridiem('A',false);addUnitAlias('hour','h');function matchMeridiem(isStrict,locale){return locale._meridiemParse;}
addRegexToken('a',matchMeridiem);addRegexToken('A',matchMeridiem);addRegexToken('H',match1to2);addRegexToken('h',match1to2);addRegexToken('HH',match1to2,match2);addRegexToken('hh',match1to2,match2);addParseToken(['H','HH'],HOUR);addParseToken(['a','A'],function(input,array,config){config._isPm=config._locale.isPM(input);config._meridiem=input;});addParseToken(['h','hh'],function(input,array,config){array[HOUR]=toInt(input);getParsingFlags(config).bigHour=true;});function localeIsPM(input){return((input+'').toLowerCase().charAt(0)==='p');}
var defaultLocaleMeridiemParse=/[ap]\.?m?\.?/i;function localeMeridiem(hours,minutes,isLower){if(hours>11){return isLower?'pm':'PM';}else{return isLower?'am':'AM';}}
var getSetHour=makeGetSet('Hours',true);addFormatToken('m',['mm',2],0,'minute');addUnitAlias('minute','m');addRegexToken('m',match1to2);addRegexToken('mm',match1to2,match2);addParseToken(['m','mm'],MINUTE);var getSetMinute=makeGetSet('Minutes',false);addFormatToken('s',['ss',2],0,'second');addUnitAlias('second','s');addRegexToken('s',match1to2);addRegexToken('ss',match1to2,match2);addParseToken(['s','ss'],SECOND);var getSetSecond=makeGetSet('Seconds',false);addFormatToken('S',0,0,function(){return~~(this.millisecond()/100);});addFormatToken(0,['SS',2],0,function(){return~~(this.millisecond()/10);});addFormatToken(0,['SSS',3],0,'millisecond');addFormatToken(0,['SSSS',4],0,function(){return this.millisecond()*10;});addFormatToken(0,['SSSSS',5],0,function(){return this.millisecond()*100;});addFormatToken(0,['SSSSSS',6],0,function(){return this.millisecond()*1000;});addFormatToken(0,['SSSSSSS',7],0,function(){return this.millisecond()*10000;});addFormatToken(0,['SSSSSSSS',8],0,function(){return this.millisecond()*100000;});addFormatToken(0,['SSSSSSSSS',9],0,function(){return this.millisecond()*1000000;});addUnitAlias('millisecond','ms');addRegexToken('S',match1to3,match1);addRegexToken('SS',match1to3,match2);addRegexToken('SSS',match1to3,match3);var token;for(token='SSSS';token.length<=9;token+='S'){addRegexToken(token,matchUnsigned);}
function parseMs(input,array){array[MILLISECOND]=toInt(('0.'+input)*1000);}
for(token='S';token.length<=9;token+='S'){addParseToken(token,parseMs);}
var getSetMillisecond=makeGetSet('Milliseconds',false);addFormatToken('z',0,0,'zoneAbbr');addFormatToken('zz',0,0,'zoneName');function getZoneAbbr(){return this._isUTC?'UTC':'';}
function getZoneName(){return this._isUTC?'Coordinated Universal Time':'';}
var momentPrototype__proto=Moment.prototype;momentPrototype__proto.add=add_subtract__add;momentPrototype__proto.calendar=moment_calendar__calendar;momentPrototype__proto.clone=clone;momentPrototype__proto.diff=diff;momentPrototype__proto.endOf=endOf;momentPrototype__proto.format=format;momentPrototype__proto.from=from;momentPrototype__proto.fromNow=fromNow;momentPrototype__proto.to=to;momentPrototype__proto.toNow=toNow;momentPrototype__proto.get=getSet;momentPrototype__proto.invalidAt=invalidAt;momentPrototype__proto.isAfter=isAfter;momentPrototype__proto.isBefore=isBefore;momentPrototype__proto.isBetween=isBetween;momentPrototype__proto.isSame=isSame;momentPrototype__proto.isValid=moment_valid__isValid;momentPrototype__proto.lang=lang;momentPrototype__proto.locale=locale;momentPrototype__proto.localeData=localeData;momentPrototype__proto.max=prototypeMax;momentPrototype__proto.min=prototypeMin;momentPrototype__proto.parsingFlags=parsingFlags;momentPrototype__proto.set=getSet;momentPrototype__proto.startOf=startOf;momentPrototype__proto.subtract=add_subtract__subtract;momentPrototype__proto.toArray=toArray;momentPrototype__proto.toObject=toObject;momentPrototype__proto.toDate=toDate;momentPrototype__proto.toISOString=moment_format__toISOString;momentPrototype__proto.toJSON=moment_format__toISOString;momentPrototype__proto.toString=toString;momentPrototype__proto.unix=unix;momentPrototype__proto.valueOf=to_type__valueOf;momentPrototype__proto.year=getSetYear;momentPrototype__proto.isLeapYear=getIsLeapYear;momentPrototype__proto.weekYear=getSetWeekYear;momentPrototype__proto.isoWeekYear=getSetISOWeekYear;momentPrototype__proto.quarter=momentPrototype__proto.quarters=getSetQuarter;momentPrototype__proto.month=getSetMonth;momentPrototype__proto.daysInMonth=getDaysInMonth;momentPrototype__proto.week=momentPrototype__proto.weeks=getSetWeek;momentPrototype__proto.isoWeek=momentPrototype__proto.isoWeeks=getSetISOWeek;momentPrototype__proto.weeksInYear=getWeeksInYear;momentPrototype__proto.isoWeeksInYear=getISOWeeksInYear;momentPrototype__proto.date=getSetDayOfMonth;momentPrototype__proto.day=momentPrototype__proto.days=getSetDayOfWeek;momentPrototype__proto.weekday=getSetLocaleDayOfWeek;momentPrototype__proto.isoWeekday=getSetISODayOfWeek;momentPrototype__proto.dayOfYear=getSetDayOfYear;momentPrototype__proto.hour=momentPrototype__proto.hours=getSetHour;momentPrototype__proto.minute=momentPrototype__proto.minutes=getSetMinute;momentPrototype__proto.second=momentPrototype__proto.seconds=getSetSecond;momentPrototype__proto.millisecond=momentPrototype__proto.milliseconds=getSetMillisecond;momentPrototype__proto.utcOffset=getSetOffset;momentPrototype__proto.utc=setOffsetToUTC;momentPrototype__proto.local=setOffsetToLocal;momentPrototype__proto.parseZone=setOffsetToParsedOffset;momentPrototype__proto.hasAlignedHourOffset=hasAlignedHourOffset;momentPrototype__proto.isDST=isDaylightSavingTime;momentPrototype__proto.isDSTShifted=isDaylightSavingTimeShifted;momentPrototype__proto.isLocal=isLocal;momentPrototype__proto.isUtcOffset=isUtcOffset;momentPrototype__proto.isUtc=isUtc;momentPrototype__proto.isUTC=isUtc;momentPrototype__proto.zoneAbbr=getZoneAbbr;momentPrototype__proto.zoneName=getZoneName;momentPrototype__proto.dates=deprecate('dates accessor is deprecated. Use date instead.',getSetDayOfMonth);momentPrototype__proto.months=deprecate('months accessor is deprecated. Use month instead',getSetMonth);momentPrototype__proto.years=deprecate('years accessor is deprecated. Use year instead',getSetYear);momentPrototype__proto.zone=deprecate('moment().zone is deprecated, use moment().utcOffset instead. https://github.com/moment/moment/issues/1779',getSetZone);var momentPrototype=momentPrototype__proto;function moment__createUnix(input){return local__createLocal(input*1000);}
function moment__createInZone(){return local__createLocal.apply(null,arguments).parseZone();}
var defaultCalendar={sameDay:'[Today at] LT',nextDay:'[Tomorrow at] LT',nextWeek:'dddd [at] LT',lastDay:'[Yesterday at] LT',lastWeek:'[Last] dddd [at] LT',sameElse:'L'};function locale_calendar__calendar(key,mom,now){var output=this._calendar[key];return typeof output==='function'?output.call(mom,now):output;}
var defaultLongDateFormat={LTS:'h:mm:ss A',LT:'h:mm A',L:'DD/MM/YYYY',LL:'D MMMM, YYYY',LLL:'D MMMM, YYYY h:mm A',LLLL:'dddd, D MMMM , YYYY h:mm A'};function longDateFormat(key){var format=this._longDateFormat[key],formatUpper=this._longDateFormat[key.toUpperCase()];if(format||!formatUpper){return format;}
this._longDateFormat[key]=formatUpper.replace(/MMMM|MM|DD|dddd/g,function(val){return val.slice(1);});return this._longDateFormat[key];}
var defaultInvalidDate='Invalid date';function invalidDate(){return this._invalidDate;}
var defaultOrdinal='%d';var defaultOrdinalParse=/\d{1,2}/;function ordinal(number){return this._ordinal.replace('%d',number);}
function preParsePostFormat(string){return string;}
var defaultRelativeTime={future:'in %s',past:'%s ago',s:'a few seconds',m:'a minute',mm:'%d minutes',h:'an hour',hh:'%d hours',d:'a day',dd:'%d days',M:'a month',MM:'%d months',y:'a year',yy:'%d years'};function relative__relativeTime(number,withoutSuffix,string,isFuture){var output=this._relativeTime[string];return(typeof output==='function')?output(number,withoutSuffix,string,isFuture):output.replace(/%d/i,number);}
function pastFuture(diff,output){var format=this._relativeTime[diff>0?'future':'past'];return typeof format==='function'?format(output):format.replace(/%s/i,output);}
function locale_set__set(config){var prop,i;for(i in config){prop=config[i];if(typeof prop==='function'){this[i]=prop;}else{this['_'+i]=prop;}}
this._ordinalParseLenient=new RegExp(this._ordinalParse.source+'|'+(/\d{1,2}/).source);}
var prototype__proto=Locale.prototype;prototype__proto._calendar=defaultCalendar;prototype__proto.calendar=locale_calendar__calendar;prototype__proto._longDateFormat=defaultLongDateFormat;prototype__proto.longDateFormat=longDateFormat;prototype__proto._invalidDate=defaultInvalidDate;prototype__proto.invalidDate=invalidDate;prototype__proto._ordinal=defaultOrdinal;prototype__proto.ordinal=ordinal;prototype__proto._ordinalParse=defaultOrdinalParse;prototype__proto.preparse=preParsePostFormat;prototype__proto.postformat=preParsePostFormat;prototype__proto._relativeTime=defaultRelativeTime;prototype__proto.relativeTime=relative__relativeTime;prototype__proto.pastFuture=pastFuture;prototype__proto.set=locale_set__set;prototype__proto.months=localeMonths;prototype__proto._months=defaultLocaleMonths;prototype__proto.monthsShort=localeMonthsShort;prototype__proto._monthsShort=defaultLocaleMonthsShort;prototype__proto.monthsParse=localeMonthsParse;prototype__proto.week=localeWeek;prototype__proto._week=defaultLocaleWeek;prototype__proto.firstDayOfYear=localeFirstDayOfYear;prototype__proto.firstDayOfWeek=localeFirstDayOfWeek;prototype__proto.weekdays=localeWeekdays;prototype__proto._weekdays=defaultLocaleWeekdays;prototype__proto.weekdaysMin=localeWeekdaysMin;prototype__proto._weekdaysMin=defaultLocaleWeekdaysMin;prototype__proto.weekdaysShort=localeWeekdaysShort;prototype__proto._weekdaysShort=defaultLocaleWeekdaysShort;prototype__proto.weekdaysParse=localeWeekdaysParse;prototype__proto.isPM=localeIsPM;prototype__proto._meridiemParse=defaultLocaleMeridiemParse;prototype__proto.meridiem=localeMeridiem;function lists__get(format,index,field,setter){var locale=locale_locales__getLocale();var utc=create_utc__createUTC().set(setter,index);return locale[field](utc,format);}
function list(format,index,field,count,setter){if(typeof format==='number'){index=format;format=undefined;}
format=format||'';if(index!=null){return lists__get(format,index,field,setter);}
var i;var out=[];for(i=0;i<count;i++){out[i]=lists__get(format,i,field,setter);}
return out;}
function lists__listMonths(format,index){return list(format,index,'months',12,'month');}
function lists__listMonthsShort(format,index){return list(format,index,'monthsShort',12,'month');}
function lists__listWeekdays(format,index){return list(format,index,'weekdays',7,'day');}
function lists__listWeekdaysShort(format,index){return list(format,index,'weekdaysShort',7,'day');}
function lists__listWeekdaysMin(format,index){return list(format,index,'weekdaysMin',7,'day');}
locale_locales__getSetGlobalLocale('en',{ordinalParse:/\d{1,2}(th|st|nd|rd)/,ordinal:function(number){var b=number%10,output=(toInt(number%100/10)===1)?'th':(b===1)?'st':(b===2)?'nd':(b===3)?'rd':'th';return number+output;}});utils_hooks__hooks.lang=deprecate('moment.lang is deprecated. Use moment.locale instead.',locale_locales__getSetGlobalLocale);utils_hooks__hooks.langData=deprecate('moment.langData is deprecated. Use moment.localeData instead.',locale_locales__getLocale);var mathAbs=Math.abs;function duration_abs__abs(){var data=this._data;this._milliseconds=mathAbs(this._milliseconds);this._days=mathAbs(this._days);this._months=mathAbs(this._months);data.milliseconds=mathAbs(data.milliseconds);data.seconds=mathAbs(data.seconds);data.minutes=mathAbs(data.minutes);data.hours=mathAbs(data.hours);data.months=mathAbs(data.months);data.years=mathAbs(data.years);return this;}
function duration_add_subtract__addSubtract(duration,input,value,direction){var other=create__createDuration(input,value);duration._milliseconds+=direction*other._milliseconds;duration._days+=direction*other._days;duration._months+=direction*other._months;return duration._bubble();}
function duration_add_subtract__add(input,value){return duration_add_subtract__addSubtract(this,input,value,1);}
function duration_add_subtract__subtract(input,value){return duration_add_subtract__addSubtract(this,input,value,-1);}
function absCeil(number){if(number<0){return Math.floor(number);}else{return Math.ceil(number);}}
function bubble(){var milliseconds=this._milliseconds;var days=this._days;var months=this._months;var data=this._data;var seconds,minutes,hours,years,monthsFromDays;if(!((milliseconds>=0&&days>=0&&months>=0)||(milliseconds<=0&&days<=0&&months<=0))){milliseconds+=absCeil(monthsToDays(months)+days)*864e5;days=0;months=0;}
data.milliseconds=milliseconds%1000;seconds=absFloor(milliseconds/1000);data.seconds=seconds%60;minutes=absFloor(seconds/60);data.minutes=minutes%60;hours=absFloor(minutes/60);data.hours=hours%24;days+=absFloor(hours/24);monthsFromDays=absFloor(daysToMonths(days));months+=monthsFromDays;days-=absCeil(monthsToDays(monthsFromDays));years=absFloor(months/12);months%=12;data.days=days;data.months=months;data.years=years;return this;}
function daysToMonths(days){return days*4800/146097;}
function monthsToDays(months){return months*146097/4800;}
function as(units){var days;var months;var milliseconds=this._milliseconds;units=normalizeUnits(units);if(units==='month'||units==='year'){days=this._days+milliseconds/864e5;months=this._months+daysToMonths(days);return units==='month'?months:months/12;}else{days=this._days+Math.round(monthsToDays(this._months));switch(units){case 'week':return days/7+milliseconds/6048e5;case 'day':return days+milliseconds/864e5;case 'hour':return days*24+milliseconds/36e5;case 'minute':return days*1440+milliseconds/6e4;case 'second':return days*86400+milliseconds/1000;case 'millisecond':return Math.floor(days*864e5)+milliseconds;default:throw new Error('Unknown unit '+units);}}}
function duration_as__valueOf(){return(this._milliseconds+
this._days*864e5+
(this._months%12)*2592e6+
toInt(this._months/12)*31536e6);}
function makeAs(alias){return function(){return this.as(alias);};}
var asMilliseconds=makeAs('ms');var asSeconds=makeAs('s');var asMinutes=makeAs('m');var asHours=makeAs('h');var asDays=makeAs('d');var asWeeks=makeAs('w');var asMonths=makeAs('M');var asYears=makeAs('y');function duration_get__get(units){units=normalizeUnits(units);return this[units+'s']();}
function makeGetter(name){return function(){return this._data[name];};}
var milliseconds=makeGetter('milliseconds');var seconds=makeGetter('seconds');var minutes=makeGetter('minutes');var hours=makeGetter('hours');var days=makeGetter('days');var months=makeGetter('months');var years=makeGetter('years');function weeks(){return absFloor(this.days()/7);}
var round=Math.round;var thresholds={s:45,m:45,h:22,d:26,M:11};function substituteTimeAgo(string,number,withoutSuffix,isFuture,locale){return locale.relativeTime(number||1,!!withoutSuffix,string,isFuture);}
function duration_humanize__relativeTime(posNegDuration,withoutSuffix,locale){var duration=create__createDuration(posNegDuration).abs();var seconds=round(duration.as('s'));var minutes=round(duration.as('m'));var hours=round(duration.as('h'));var days=round(duration.as('d'));var months=round(duration.as('M'));var years=round(duration.as('y'));var a=seconds<thresholds.s&&['s',seconds]||minutes===1&&['m']||minutes<thresholds.m&&['mm',minutes]||hours===1&&['h']||hours<thresholds.h&&['hh',hours]||days===1&&['d']||days<thresholds.d&&['dd',days]||months===1&&['M']||months<thresholds.M&&['MM',months]||years===1&&['y']||['yy',years];a[2]=withoutSuffix;a[3]=+posNegDuration>0;a[4]=locale;return substituteTimeAgo.apply(null,a);}
function duration_humanize__getSetRelativeTimeThreshold(threshold,limit){if(thresholds[threshold]===undefined){return false;}
if(limit===undefined){return thresholds[threshold];}
thresholds[threshold]=limit;return true;}
function humanize(withSuffix){var locale=this.localeData();var output=duration_humanize__relativeTime(this,!withSuffix,locale);if(withSuffix){output=locale.pastFuture(+this,output);}
return locale.postformat(output);}
var iso_string__abs=Math.abs;function iso_string__toISOString(){var seconds=iso_string__abs(this._milliseconds)/1000;var days=iso_string__abs(this._days);var months=iso_string__abs(this._months);var minutes,hours,years;minutes=absFloor(seconds/60);hours=absFloor(minutes/60);seconds%=60;minutes%=60;years=absFloor(months/12);months%=12;var Y=years;var M=months;var D=days;var h=hours;var m=minutes;var s=seconds;var total=this.asSeconds();if(!total){return 'P0D';}
return(total<0?'-':'')+
'P'+
(D?D+'D':'')+
(M?M+'M':'')+
 (Y?Y+'Y':'')+
((h||m||s)?'T':'')+
(h?h+'H':'')+
(m?m+'M':'')+
(s?s+'S':'');}
var duration_prototype__proto=Duration.prototype;duration_prototype__proto.abs=duration_abs__abs;duration_prototype__proto.add=duration_add_subtract__add;duration_prototype__proto.subtract=duration_add_subtract__subtract;duration_prototype__proto.as=as;duration_prototype__proto.asMilliseconds=asMilliseconds;duration_prototype__proto.asSeconds=asSeconds;duration_prototype__proto.asMinutes=asMinutes;duration_prototype__proto.asHours=asHours;duration_prototype__proto.asDays=asDays;duration_prototype__proto.asWeeks=asWeeks;duration_prototype__proto.asMonths=asMonths;duration_prototype__proto.asYears=asYears;duration_prototype__proto.valueOf=duration_as__valueOf;duration_prototype__proto._bubble=bubble;duration_prototype__proto.get=duration_get__get;duration_prototype__proto.milliseconds=milliseconds;duration_prototype__proto.seconds=seconds;duration_prototype__proto.minutes=minutes;duration_prototype__proto.hours=hours;duration_prototype__proto.days=days;duration_prototype__proto.weeks=weeks;duration_prototype__proto.months=months;duration_prototype__proto.years=years;duration_prototype__proto.humanize=humanize;duration_prototype__proto.toISOString=iso_string__toISOString;duration_prototype__proto.toString=iso_string__toISOString;duration_prototype__proto.toJSON=iso_string__toISOString;duration_prototype__proto.locale=locale;duration_prototype__proto.localeData=localeData;duration_prototype__proto.toIsoString=deprecate('toIsoString() is deprecated. Please use toISOString() instead (notice the capitals)',iso_string__toISOString);duration_prototype__proto.lang=lang;addFormatToken('X',0,0,'unix');addFormatToken('x',0,0,'valueOf');addRegexToken('x',matchSigned);addRegexToken('X',matchTimestamp);addParseToken('X',function(input,array,config){config._d=new Date(parseFloat(input,10)*1000);});addParseToken('x',function(input,array,config){config._d=new Date(toInt(input));});utils_hooks__hooks.version='2.10.6';setHookCallback(local__createLocal);utils_hooks__hooks.fn=momentPrototype;utils_hooks__hooks.min=min;utils_hooks__hooks.max=max;utils_hooks__hooks.utc=create_utc__createUTC;utils_hooks__hooks.unix=moment__createUnix;utils_hooks__hooks.months=lists__listMonths;utils_hooks__hooks.isDate=isDate;utils_hooks__hooks.locale=locale_locales__getSetGlobalLocale;utils_hooks__hooks.invalid=valid__createInvalid;utils_hooks__hooks.duration=create__createDuration;utils_hooks__hooks.isMoment=isMoment;utils_hooks__hooks.weekdays=lists__listWeekdays;utils_hooks__hooks.parseZone=moment__createInZone;utils_hooks__hooks.localeData=locale_locales__getLocale;utils_hooks__hooks.isDuration=isDuration;utils_hooks__hooks.monthsShort=lists__listMonthsShort;utils_hooks__hooks.weekdaysMin=lists__listWeekdaysMin;utils_hooks__hooks.defineLocale=defineLocale;utils_hooks__hooks.weekdaysShort=lists__listWeekdaysShort;utils_hooks__hooks.normalizeUnits=normalizeUnits;utils_hooks__hooks.relativeTimeThreshold=duration_humanize__getSetRelativeTimeThreshold;var _moment=utils_hooks__hooks;return _moment;}));},{}],34:[function(require,module,exports){'use strict';var crossvent=require('crossvent');var throttle=require('./throttle');var tailormade=require('./tailormade');function bullseye(el,target,options){var o=options;var domTarget=target&&target.tagName;if(!domTarget&&arguments.length===2){o=target;}
if(!domTarget){target=el;}
if(!o){o={};}
var destroyed=false;var throttledWrite=throttle(write,30);var tailorOptions={update:o.autoupdateToCaret!==false&&update};var tailor=o.caret&&tailormade(target,tailorOptions);write();if(o.tracking!==false){crossvent.add(window,'resize',throttledWrite);}
return{read:readNull,refresh:write,destroy:destroy,sleep:sleep};function sleep(){tailorOptions.sleeping=true;}
function readNull(){return read();}
function read(readings){var bounds=target.getBoundingClientRect();var scrollTop=document.body.scrollTop||document.documentElement.scrollTop;if(tailor){readings=tailor.read();return{x:(readings.absolute?0:bounds.left)+readings.x,y:(readings.absolute?0:bounds.top)+scrollTop+readings.y+20};}
return{x:bounds.left,y:bounds.top+scrollTop};}
function update(readings){write(readings);}
function write(readings){if(destroyed){throw new Error('Bullseye can\'t refresh after being destroyed. Create another instance instead.');}
if(tailor&&!readings){tailorOptions.sleeping=false;tailor.refresh();return;}
var p=read(readings);if(!tailor&&target!==el){p.y+=target.offsetHeight;}
el.style.left=p.x+'px';el.style.top=p.y+'px';}
function destroy(){if(tailor){tailor.destroy();}
crossvent.remove(window,'resize',throttledWrite);destroyed=true;}}
module.exports=bullseye;},{"./tailormade":44,"./throttle":45,"crossvent":51}],35:[function(require,module,exports){(function(global){'use strict';var getSelection;var doc=global.document;var getSelectionRaw=require('./getSelectionRaw');var getSelectionNullOp=require('./getSelectionNullOp');var getSelectionSynthetic=require('./getSelectionSynthetic');var isHost=require('./isHost');if(isHost.method(global,'getSelection')){getSelection=getSelectionRaw;}else if(typeof doc.selection==='object'&&doc.selection){getSelection=getSelectionSynthetic;}else{getSelection=getSelectionNullOp;}
module.exports=getSelection;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./getSelectionNullOp":36,"./getSelectionRaw":37,"./getSelectionSynthetic":38,"./isHost":39}],36:[function(require,module,exports){'use strict';function noop(){}
function getSelectionNullOp(){return{removeAllRanges:noop,addRange:noop};}
module.exports=getSelectionNullOp;},{}],37:[function(require,module,exports){(function(global){'use strict';function getSelectionRaw(){return global.getSelection();}
module.exports=getSelectionRaw;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],38:[function(require,module,exports){(function(global){'use strict';var rangeToTextRange=require('./rangeToTextRange');var doc=global.document;var body=doc.body;var GetSelectionProto=GetSelection.prototype;function GetSelection(selection){var self=this;var range=selection.createRange();this._selection=selection;this._ranges=[];if(selection.type==='Control'){updateControlSelection(self);}else if(isTextRange(range)){updateFromTextRange(self,range);}else{updateEmptySelection(self);}}
GetSelectionProto.removeAllRanges=function(){var textRange;try{this._selection.empty();if(this._selection.type!=='None'){textRange=body.createTextRange();textRange.select();this._selection.empty();}}catch(e){}
updateEmptySelection(this);};GetSelectionProto.addRange=function(range){if(this._selection.type==='Control'){addRangeToControlSelection(this,range);}else{rangeToTextRange(range).select();this._ranges[0]=range;this.rangeCount=1;this.isCollapsed=this._ranges[0].collapsed;updateAnchorAndFocusFromRange(this,range,false);}};GetSelectionProto.setRanges=function(ranges){this.removeAllRanges();var rangeCount=ranges.length;if(rangeCount>1){createControlSelection(this,ranges);}else if(rangeCount){this.addRange(ranges[0]);}};GetSelectionProto.getRangeAt=function(index){if(index<0||index>=this.rangeCount){throw new Error('getRangeAt(): index out of bounds');}else{return this._ranges[index].cloneRange();}};GetSelectionProto.removeRange=function(range){if(this._selection.type!=='Control'){removeRangeManually(this,range);return;}
var controlRange=this._selection.createRange();var rangeElement=getSingleElementFromRange(range);var newControlRange=body.createControlRange();var el;var removed=false;for(var i=0,len=controlRange.length;i<len;++i){el=controlRange.item(i);if(el!==rangeElement||removed){newControlRange.add(controlRange.item(i));}else{removed=true;}}
newControlRange.select();updateControlSelection(this);};GetSelectionProto.eachRange=function(fn,returnValue){var i=0;var len=this._ranges.length;for(i=0;i<len;++i){if(fn(this.getRangeAt(i))){return returnValue;}}};GetSelectionProto.getAllRanges=function(){var ranges=[];this.eachRange(function(range){ranges.push(range);});return ranges;};GetSelectionProto.setSingleRange=function(range){this.removeAllRanges();this.addRange(range);};function createControlSelection(sel,ranges){var controlRange=body.createControlRange();for(var i=0,el,len=ranges.length;i<len;++i){el=getSingleElementFromRange(ranges[i]);try{controlRange.add(el);}catch(e){throw new Error('setRanges(): Element could not be added to control selection');}}
controlRange.select();updateControlSelection(sel);}
function removeRangeManually(sel,range){var ranges=sel.getAllRanges();sel.removeAllRanges();for(var i=0,len=ranges.length;i<len;++i){if(!isSameRange(range,ranges[i])){sel.addRange(ranges[i]);}}
if(!sel.rangeCount){updateEmptySelection(sel);}}
function updateAnchorAndFocusFromRange(sel,range){var anchorPrefix='start';var focusPrefix='end';sel.anchorNode=range[anchorPrefix+'Container'];sel.anchorOffset=range[anchorPrefix+'Offset'];sel.focusNode=range[focusPrefix+'Container'];sel.focusOffset=range[focusPrefix+'Offset'];}
function updateEmptySelection(sel){sel.anchorNode=sel.focusNode=null;sel.anchorOffset=sel.focusOffset=0;sel.rangeCount=0;sel.isCollapsed=true;sel._ranges.length=0;}
function rangeContainsSingleElement(rangeNodes){if(!rangeNodes.length||rangeNodes[0].nodeType!==1){return false;}
for(var i=1,len=rangeNodes.length;i<len;++i){if(!isAncestorOf(rangeNodes[0],rangeNodes[i])){return false;}}
return true;}
function getSingleElementFromRange(range){var nodes=range.getNodes();if(!rangeContainsSingleElement(nodes)){throw new Error('getSingleElementFromRange(): range did not consist of a single element');}
return nodes[0];}
function isTextRange(range){return range&&range.text!==void 0;}
function updateFromTextRange(sel,range){sel._ranges=[range];updateAnchorAndFocusFromRange(sel,range,false);sel.rangeCount=1;sel.isCollapsed=range.collapsed;}
function updateControlSelection(sel){sel._ranges.length=0;if(sel._selection.type==='None'){updateEmptySelection(sel);}else{var controlRange=sel._selection.createRange();if(isTextRange(controlRange)){updateFromTextRange(sel,controlRange);}else{sel.rangeCount=controlRange.length;var range;for(var i=0;i<sel.rangeCount;++i){range=doc.createRange();range.selectNode(controlRange.item(i));sel._ranges.push(range);}
sel.isCollapsed=sel.rangeCount===1&&sel._ranges[0].collapsed;updateAnchorAndFocusFromRange(sel,sel._ranges[sel.rangeCount-1],false);}}}
function addRangeToControlSelection(sel,range){var controlRange=sel._selection.createRange();var rangeElement=getSingleElementFromRange(range);var newControlRange=body.createControlRange();for(var i=0,len=controlRange.length;i<len;++i){newControlRange.add(controlRange.item(i));}
try{newControlRange.add(rangeElement);}catch(e){throw new Error('addRange(): Element could not be added to control selection');}
newControlRange.select();updateControlSelection(sel);}
function isSameRange(left,right){return(left.startContainer===right.startContainer&&left.startOffset===right.startOffset&&left.endContainer===right.endContainer&&left.endOffset===right.endOffset);}
function isAncestorOf(ancestor,descendant){var node=descendant;while(node.parentNode){if(node.parentNode===ancestor){return true;}
node=node.parentNode;}
return false;}
function getSelection(){return new GetSelection(global.document.selection);}
module.exports=getSelection;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./rangeToTextRange":40}],39:[function(require,module,exports){'use strict';function isHostMethod(host,prop){var type=typeof host[prop];return type==='function'||!!(type==='object'&&host[prop])||type==='unknown';}
function isHostProperty(host,prop){return typeof host[prop]!=='undefined';}
function many(fn){return function areHosted(host,props){var i=props.length;while(i--){if(!fn(host,props[i])){return false;}}
return true;};}
module.exports={method:isHostMethod,methods:many(isHostMethod),property:isHostProperty,properties:many(isHostProperty)};},{}],40:[function(require,module,exports){(function(global){'use strict';var doc=global.document;var body=doc.body;function rangeToTextRange(p){if(p.collapsed){return createBoundaryTextRange({node:p.startContainer,offset:p.startOffset},true);}
var startRange=createBoundaryTextRange({node:p.startContainer,offset:p.startOffset},true);var endRange=createBoundaryTextRange({node:p.endContainer,offset:p.endOffset},false);var textRange=body.createTextRange();textRange.setEndPoint('StartToStart',startRange);textRange.setEndPoint('EndToEnd',endRange);return textRange;}
function isCharacterDataNode(node){var t=node.nodeType;return t===3||t===4||t===8;}
function createBoundaryTextRange(p,starting){var bound;var parent;var offset=p.offset;var workingNode;var childNodes;var range=body.createTextRange();var data=isCharacterDataNode(p.node);if(data){bound=p.node;parent=bound.parentNode;}else{childNodes=p.node.childNodes;bound=offset<childNodes.length?childNodes[offset]:null;parent=p.node;}
workingNode=doc.createElement('span');workingNode.innerHTML='&#feff;';if(bound){parent.insertBefore(workingNode,bound);}else{parent.appendChild(workingNode);}
range.moveToElementText(workingNode);range.collapse(!starting);parent.removeChild(workingNode);if(data){range[starting?'moveStart':'moveEnd']('character',offset);}
return range;}
module.exports=rangeToTextRange;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],41:[function(require,module,exports){'use strict';var getSelection=require('./getSelection');var setSelection=require('./setSelection');module.exports={get:getSelection,set:setSelection};},{"./getSelection":35,"./setSelection":42}],42:[function(require,module,exports){(function(global){'use strict';var getSelection=require('./getSelection');var rangeToTextRange=require('./rangeToTextRange');var doc=global.document;function setSelection(p){if(doc.createRange){modernSelection();}else{oldSelection();}
function modernSelection(){var sel=getSelection();var range=doc.createRange();if(!p.startContainer){return;}
if(p.endContainer){range.setEnd(p.endContainer,p.endOffset);}else{range.setEnd(p.startContainer,p.startOffset);}
range.setStart(p.startContainer,p.startOffset);sel.removeAllRanges();sel.addRange(range);}
function oldSelection(){rangeToTextRange(p).select();}}
module.exports=setSelection;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./getSelection":35,"./rangeToTextRange":40}],43:[function(require,module,exports){'use strict';var get=easyGet;var set=easySet;if(document.selection&&document.selection.createRange){get=hardGet;set=hardSet;}
function easyGet(el){return{start:el.selectionStart,end:el.selectionEnd};}
function hardGet(el){var active=document.activeElement;if(active!==el){el.focus();}
var range=document.selection.createRange();var bookmark=range.getBookmark();var original=el.value;var marker=getUniqueMarker(original);var parent=range.parentElement();if(parent===null||!inputs(parent)){return result(0,0);}
range.text=marker+range.text+marker;var contents=el.value;el.value=original;range.moveToBookmark(bookmark);range.select();return result(contents.indexOf(marker),contents.lastIndexOf(marker)-marker.length);function result(start,end){if(active!==el){if(active){active.focus();}else{el.blur();}}
return{start:start,end:end};}}
function getUniqueMarker(contents){var marker;do{marker='@@marker.'+Math.random()*new Date();}while(contents.indexOf(marker)!==-1);return marker;}
function inputs(el){return((el.tagName==='INPUT'&&el.type==='text')||el.tagName==='TEXTAREA');}
function easySet(el,p){el.selectionStart=parse(el,p.start);el.selectionEnd=parse(el,p.end);}
function hardSet(el,p){var range=el.createTextRange();if(p.start==='end'&&p.end==='end'){range.collapse(false);range.select();}else{range.collapse(true);range.moveEnd('character',parse(el,p.end));range.moveStart('character',parse(el,p.start));range.select();}}
function parse(el,value){return value==='end'?el.value.length:value||0;}
function sell(el,p){if(arguments.length===2){set(el,p);}
return get(el);}
module.exports=sell;},{}],44:[function(require,module,exports){(function(global){'use strict';var sell=require('sell');var crossvent=require('crossvent');var seleccion=require('seleccion');var throttle=require('./throttle');var getSelection=seleccion.get;var props=['direction','boxSizing','width','height','overflowX','overflowY','borderTopWidth','borderRightWidth','borderBottomWidth','borderLeftWidth','paddingTop','paddingRight','paddingBottom','paddingLeft','fontStyle','fontVariant','fontWeight','fontStretch','fontSize','fontSizeAdjust','lineHeight','fontFamily','textAlign','textTransform','textIndent','textDecoration','letterSpacing','wordSpacing'];var win=global;var doc=document;var ff=win.mozInnerScreenX!==null&&win.mozInnerScreenX!==void 0;function tailormade(el,options){var textInput=el.tagName==='INPUT'||el.tagName==='TEXTAREA';var throttledRefresh=throttle(refresh,30);var o=options||{};bind();return{read:readPosition,refresh:throttledRefresh,destroy:destroy};function noop(){}
function readPosition(){return(textInput?coordsText:coordsHTML)();}
function refresh(){if(o.sleeping){return;}
return(o.update||noop)(readPosition());}
function coordsText(){var p=sell(el);var context=prepare();var readings=readTextCoords(context,p.start);doc.body.removeChild(context.mirror);return readings;}
function coordsHTML(){var sel=getSelection();if(sel.rangeCount){var range=sel.getRangeAt(0);var needsToWorkAroundNewlineBug=range.startContainer.nodeName==='P'&&range.startOffset===0;if(needsToWorkAroundNewlineBug){return{x:range.startContainer.offsetLeft,y:range.startContainer.offsetTop,absolute:true};}
if(range.getClientRects){var rects=range.getClientRects();if(rects.length>0){return{x:rects[0].left,y:rects[0].top,absolute:true};}}}
return{x:0,y:0};}
function readTextCoords(context,p){var rest=doc.createElement('span');var mirror=context.mirror;var computed=context.computed;write(mirror,read(el).substring(0,p));if(el.tagName==='INPUT'){mirror.textContent=mirror.textContent.replace(/\s/g,'\u00a0');}
write(rest,read(el).substring(p)||'.');mirror.appendChild(rest);return{x:rest.offsetLeft+parseInt(computed['borderLeftWidth']),y:rest.offsetTop+parseInt(computed['borderTopWidth'])};}
function read(el){return textInput?el.value:el.innerHTML;}
function prepare(){var computed=win.getComputedStyle?getComputedStyle(el):el.currentStyle;var mirror=doc.createElement('div');var style=mirror.style;doc.body.appendChild(mirror);if(el.tagName!=='INPUT'){style.wordWrap='break-word';}
style.whiteSpace='pre-wrap';style.position='absolute';style.visibility='hidden';props.forEach(copy);if(ff){style.width=parseInt(computed.width)-2+'px';if(el.scrollHeight>parseInt(computed.height)){style.overflowY='scroll';}}else{style.overflow='hidden';}
return{mirror:mirror,computed:computed};function copy(prop){style[prop]=computed[prop];}}
function write(el,value){if(textInput){el.textContent=value;}else{el.innerHTML=value;}}
function bind(remove){var op=remove?'remove':'add';crossvent[op](el,'keydown',throttledRefresh);crossvent[op](el,'keyup',throttledRefresh);crossvent[op](el,'input',throttledRefresh);crossvent[op](el,'paste',throttledRefresh);crossvent[op](el,'change',throttledRefresh);}
function destroy(){bind(true);}}
module.exports=tailormade;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./throttle":45,"crossvent":51,"seleccion":41,"sell":43}],45:[function(require,module,exports){'use strict';function throttle(fn,boundary){var last=-Infinity;var timer;return function bounced(){if(timer){return;}
unbound();function unbound(){clearTimeout(timer);timer=null;var next=last+boundary;var now=Date.now();if(now>next){last=now;fn();}else{timer=setTimeout(unbound,next-now);}}};}
module.exports=throttle;},{}],46:[function(require,module,exports){'use strict';var ticky=require('ticky');module.exports=function debounce(fn,args,ctx){if(!fn){return;}
ticky(function run(){fn.apply(ctx||null,args||[]);});};},{"ticky":49}],47:[function(require,module,exports){'use strict';var atoa=require('atoa');var debounce=require('./debounce');module.exports=function emitter(thing,options){var opts=options||{};var evt={};if(thing===undefined){thing={};}
thing.on=function(type,fn){if(!evt[type]){evt[type]=[fn];}else{evt[type].push(fn);}
return thing;};thing.once=function(type,fn){fn._once=true;thing.on(type,fn);return thing;};thing.off=function(type,fn){var c=arguments.length;if(c===1){delete evt[type];}else if(c===0){evt={};}else{var et=evt[type];if(!et){return thing;}
et.splice(et.indexOf(fn),1);}
return thing;};thing.emit=function(){var args=atoa(arguments);return thing.emitterSnapshot(args.shift()).apply(this,args);};thing.emitterSnapshot=function(type){var et=(evt[type]||[]).slice(0);return function(){var args=atoa(arguments);var ctx=this||thing;if(type==='error'&&opts.throws!==false&&!et.length){throw args.length===1?args[0]:args;}
et.forEach(function emitter(listen){if(opts.async){debounce(listen,args,ctx);}else{listen.apply(ctx,args);}
if(listen._once){thing.off(type,listen);}});return thing;};};return thing;};},{"./debounce":46,"atoa":48}],48:[function(require,module,exports){module.exports=function atoa(a,n){return Array.prototype.slice.call(a,n);}},{}],49:[function(require,module,exports){var si=typeof setImmediate==='function',tick;if(si){tick=function(fn){setImmediate(fn);};}else{tick=function(fn){setTimeout(fn,0);};}
module.exports=tick;},{}],50:[function(require,module,exports){(function(global){var NativeCustomEvent=global.CustomEvent;function useNative(){try{var p=new NativeCustomEvent('cat',{detail:{foo:'bar'}});return 'cat'===p.type&&'bar'===p.detail.foo;}catch(e){}
return false;}
module.exports=useNative()?NativeCustomEvent:'function'===typeof document.createEvent?function CustomEvent(type,params){var e=document.createEvent('CustomEvent');if(params){e.initCustomEvent(type,params.bubbles,params.cancelable,params.detail);}else{e.initCustomEvent(type,false,false,void 0);}
return e;}:function CustomEvent(type,params){var e=document.createEventObject();e.type=type;if(params){e.bubbles=Boolean(params.bubbles);e.cancelable=Boolean(params.cancelable);e.detail=params.detail;}else{e.bubbles=false;e.cancelable=false;e.detail=void 0;}
return e;}}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],51:[function(require,module,exports){(function(global){'use strict';var customEvent=require('custom-event');var eventmap=require('./eventmap');var doc=document;var addEvent=addEventEasy;var removeEvent=removeEventEasy;var hardCache=[];if(!global.addEventListener){addEvent=addEventHard;removeEvent=removeEventHard;}
function addEventEasy(el,type,fn,capturing){return el.addEventListener(type,fn,capturing);}
function addEventHard(el,type,fn){return el.attachEvent('on'+type,wrap(el,type,fn));}
function removeEventEasy(el,type,fn,capturing){return el.removeEventListener(type,fn,capturing);}
function removeEventHard(el,type,fn){return el.detachEvent('on'+type,unwrap(el,type,fn));}
function fabricateEvent(el,type,model){var e=eventmap.indexOf(type)===-1?makeCustomEvent():makeClassicEvent();if(el.dispatchEvent){el.dispatchEvent(e);}else{el.fireEvent('on'+type,e);}
function makeClassicEvent(){var e;if(doc.createEvent){e=doc.createEvent('Event');e.initEvent(type,true,true);}else if(doc.createEventObject){e=doc.createEventObject();}
return e;}
function makeCustomEvent(){return new customEvent(type,{detail:model});}}
function wrapperFactory(el,type,fn){return function wrapper(originalEvent){var e=originalEvent||global.event;e.target=e.target||e.srcElement;e.preventDefault=e.preventDefault||function preventDefault(){e.returnValue=false;};e.stopPropagation=e.stopPropagation||function stopPropagation(){e.cancelBubble=true;};e.which=e.which||e.keyCode;fn.call(el,e);};}
function wrap(el,type,fn){var wrapper=unwrap(el,type,fn)||wrapperFactory(el,type,fn);hardCache.push({wrapper:wrapper,element:el,type:type,fn:fn});return wrapper;}
function unwrap(el,type,fn){var i=find(el,type,fn);if(i){var wrapper=hardCache[i].wrapper;hardCache.splice(i,1);return wrapper;}}
function find(el,type,fn){var i,item;for(i=0;i<hardCache.length;i++){item=hardCache[i];if(item.element===el&&item.type===type&&item.fn===fn){return i;}}}
module.exports={add:addEvent,remove:removeEvent,fabricate:fabricateEvent};}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{"./eventmap":52,"custom-event":50}],52:[function(require,module,exports){(function(global){'use strict';var eventmap=[];var eventname='';var ron=/^on/;for(eventname in global){if(ron.test(eventname)){eventmap.push(eventname.slice(2));}}
module.exports=eventmap;}).call(this,typeof global!=="undefined"?global:typeof self!=="undefined"?self:typeof window!=="undefined"?window:{})},{}],53:[function(require,module,exports){arguments[4][33][0].apply(exports,arguments)},{"dup":33}],54:[function(require,module,exports){'use strict';var isInput=require('./isInput');var bindings={};function has(source,target){var binding=bindings[source.id];return binding&&binding[target.id];}
function insert(source,target){var binding=bindings[source.id];if(!binding){binding=bindings[source.id]={};}
var invalidate=invalidator(target);binding[target.id]=invalidate;source.on('data',invalidate);source.on('destroyed',remove.bind(null,source,target));}
function remove(source,target){var binding=bindings[source.id];if(!binding){return;}
var invalidate=binding[target.id];source.off('data',invalidate);delete binding[target.id];}
function invalidator(target){return function invalidate(){target.refresh();};}
function add(source,target){if(isInput(target.associated)||has(source,target)){return;}
insert(source,target);}
module.exports={add:add,remove:remove};},{"./isInput":64}],55:[function(require,module,exports){'use strict';var crossvent=require('crossvent');var emitter=require('contra/emitter');var dom=require('./dom');var text=require('./text');var parse=require('./parse');var clone=require('./clone');var defaults=require('./defaults');var momentum=require('./momentum');var classes=require('./classes');var noop=require('./noop');var no;function calendar(calendarOptions){var o;var ref;var refCal;var container;var rendered=false;var monthOffsetAttribute='data-rome-offset';var weekdays;var weekdayCount;var calendarMonths=[];var lastYear;var lastMonth;var lastDay;var lastDayElement;var datewrapper;var back;var next;var secondsInDay=60*60*24;var time;var timelist;var api=emitter({associated:calendarOptions.associated});init();setTimeout(ready,0);return api;function napi(){return api;}
function init(initOptions){o=defaults(initOptions||calendarOptions,api);if(!container){container=dom({className:o.styles.container});}
weekdays=o.weekdayFormat;weekdayCount=weekdays.length;lastMonth=no;lastYear=no;lastDay=no;lastDayElement=no;o.appendTo.appendChild(container);removeChildren(container);rendered=false;ref=o.initialValue?o.initialValue:momentum.moment();refCal=ref.clone();api.back=subtractMonth;api.container=container;api.destroyed=false;api.destroy=destroy.bind(api,false);api.emitValues=emitValues;api.getDate=getDate;api.getDateString=getDateString;api.getMoment=getMoment;api.hide=hide;api.next=addMonth;api.options=changeOptions;api.options.reset=resetOptions;api.refresh=refresh;api.restore=napi;api.setValue=setValue;api.show=show;eventListening();ready();return api;}
function ready(){api.emit('ready',clone(o));}
function destroy(silent){if(container&&container.parentNode){container.parentNode.removeChild(container);}
if(o){eventListening(true);}
var destroyed=api.emitterSnapshot('destroyed');api.back=noop;api.destroyed=true;api.destroy=napi;api.emitValues=napi;api.getDate=noop;api.getDateString=noop;api.getMoment=noop;api.hide=napi;api.next=noop;api.options=napi;api.options.reset=napi;api.refresh=napi;api.restore=init;api.setValue=napi;api.show=napi;api.off();if(silent!==true){destroyed();}
return api;}
function eventListening(remove){var op=remove?'remove':'add';if(o.autoHideOnBlur){crossvent[op](document.documentElement,'focus',hideOnBlur,true);}
if(o.autoHideOnClick){crossvent[op](document,'click',hideOnClick);}}
function changeOptions(options){if(arguments.length===0){return clone(o);}
destroy();init(options);return api;}
function resetOptions(){return changeOptions({appendTo:o.appendTo});}
function render(){if(rendered){return;}
rendered=true;renderDates();renderTime();api.emit('render');}
function renderDates(){if(!o.date){return;}
var i;calendarMonths=[];datewrapper=dom({className:o.styles.date,parent:container});for(i=0;i<o.monthsInCalendar;i++){renderMonth(i);}
crossvent.add(back,'click',subtractMonth);crossvent.add(next,'click',addMonth);crossvent.add(datewrapper,'click',pickDay);function renderMonth(i){var month=dom({className:o.styles.month,parent:datewrapper});if(i===0){back=dom({type:'button',className:o.styles.back,attributes:{type:'button'},parent:month});}
if(i===o.monthsInCalendar-1){next=dom({type:'button',className:o.styles.next,attributes:{type:'button'},parent:month});}
var label=dom({className:o.styles.monthLabel,parent:month});var date=dom({type:'table',className:o.styles.dayTable,parent:month});var datehead=dom({type:'thead',className:o.styles.dayHead,parent:date});var dateheadrow=dom({type:'tr',className:o.styles.dayRow,parent:datehead});var datebody=dom({type:'tbody',className:o.styles.dayBody,parent:date});var j;for(j=0;j<weekdayCount;j++){dom({type:'th',className:o.styles.dayHeadElem,parent:dateheadrow,text:weekdays[weekday(j)]});}
datebody.setAttribute(monthOffsetAttribute,i);calendarMonths.push({label:label,body:datebody});}}
function renderTime(){if(!o.time||!o.timeInterval){return;}
var timewrapper=dom({className:o.styles.time,parent:container});time=dom({className:o.styles.selectedTime,parent:timewrapper,text:ref.format(o.timeFormat)});crossvent.add(time,'click',toggleTimeList);timelist=dom({className:o.styles.timeList,parent:timewrapper});crossvent.add(timelist,'click',pickTime);var next=momentum.moment('00:00:00','HH:mm:ss');var latest=next.clone().add(1,'days');while(next.isBefore(latest)){dom({className:o.styles.timeOption,parent:timelist,text:next.format(o.timeFormat)});next.add(o.timeInterval,'seconds');}}
function weekday(index,backwards){var factor=backwards?-1:1;var offset=index+o.weekStart*factor;if(offset>=weekdayCount||offset<0){offset+=weekdayCount*-factor;}
return offset;}
function displayValidTimesOnly(){if(!o.time||!rendered){return;}
var times=timelist.children;var length=times.length;var date;var time;var item;var i;for(i=0;i<length;i++){item=times[i];time=momentum.moment(text(item),o.timeFormat);date=setTime(ref.clone(),time);item.style.display=isInRange(date,false,o.timeValidator)?'block':'none';}}
function toggleTimeList(show){var display=typeof show==='boolean'?show:timelist.style.display==='none';if(display){showTimeList();}else{hideTimeList();}}
function showTimeList(){if(timelist){timelist.style.display='block';}}
function hideTimeList(){if(timelist){timelist.style.display='none';}}
function showCalendar(){container.style.display='inline-block';api.emit('show');}
function hideCalendar(){if(container.style.display!=='none'){container.style.display='none';api.emit('hide');}}
function show(){render();refresh();toggleTimeList(!o.date);showCalendar();return api;}
function hide(){hideTimeList();setTimeout(hideCalendar,0);return api;}
function hideConditionally(){hideTimeList();var pos=classes.contains(container,o.styles.positioned);if(pos){setTimeout(hideCalendar,0);}
return api;}
function calendarEventTarget(e){var target=e.target;if(target===api.associated){return true;}
while(target){if(target===container){return true;}
target=target.parentNode;}}
function hideOnBlur(e){if(calendarEventTarget(e)){return;}
hideConditionally();}
function hideOnClick(e){if(calendarEventTarget(e)){return;}
hideConditionally();}
function subtractMonth(){changeMonth('subtract');}
function addMonth(){changeMonth('add');}
function changeMonth(op){var bound;var direction=op==='add'?-1:1;var offset=o.monthsInCalendar+direction*getMonthOffset(lastDayElement);refCal[op](offset,'months');bound=inRange(refCal.clone());ref=bound||ref;if(bound){refCal=bound.clone();}
update();api.emit(op==='add'?'next':'back',ref.month());}
function update(silent){updateCalendar();updateTime();if(silent!==true){emitValues();}
displayValidTimesOnly();}
function updateCalendar(){if(!o.date||!rendered){return;}
var y=refCal.year();var m=refCal.month();var d=refCal.date();if(d===lastDay&&m===lastMonth&&y===lastYear){return;}
var canStay=isDisplayed();lastDay=refCal.date();lastMonth=refCal.month();lastYear=refCal.year();if(canStay){updateCalendarSelection();return;}
calendarMonths.forEach(updateMonth);renderAllDays();function updateMonth(month,i){var offsetCal=refCal.clone().add(i,'months');text(month.label,offsetCal.format(o.monthFormat));removeChildren(month.body);}}
function updateCalendarSelection(){var day=refCal.date()-1;selectDayElement(false);calendarMonths.forEach(function(cal){var days;if(sameCalendarMonth(cal.date,refCal)){days=cast(cal.body.children).map(aggregate);days=Array.prototype.concat.apply([],days).filter(inside);selectDayElement(days[day]);}});function cast(like){var dest=[];var i;for(i=0;i<like.length;i++){dest.push(like[i]);}
return dest;}
function aggregate(child){return cast(child.children);}
function inside(child){return!classes.contains(child,o.styles.dayPrevMonth)&&!classes.contains(child,o.styles.dayNextMonth);}}
function isDisplayed(){return calendarMonths.some(matches);function matches(cal){if(!lastYear){return false;}
return sameCalendarMonth(cal.date,refCal);}}
function sameCalendarMonth(left,right){return left&&right&&left.year()===right.year()&&left.month()===right.month();}
function updateTime(){if(!o.time||!rendered){return;}
text(time,ref.format(o.timeFormat));}
function emitValues(){api.emit('data',getDateString());api.emit('year',ref.year());api.emit('month',ref.month());api.emit('day',ref.day());api.emit('time',ref.format(o.timeFormat));return api;}
function refresh(){lastYear=false;lastMonth=false;lastDay=false;update(true);return api;}
function setValue(value){var date=parse(value,o.inputFormat);if(date===null){return;}
ref=inRange(date)||ref;refCal=ref.clone();update(true);return api;}
function removeChildren(elem,self){while(elem&&elem.firstChild){elem.removeChild(elem.firstChild);}
if(self===true){elem.parentNode.removeChild(elem);}}
function renderAllDays(){var i;for(i=0;i<o.monthsInCalendar;i++){renderDays(i);}}
function renderDays(offset){var month=calendarMonths[offset];var offsetCal=refCal.clone().add(offset,'months');var total=offsetCal.daysInMonth();var current=offsetCal.month()!==ref.month()?-1:ref.date();var first=offsetCal.clone().date(1);var firstDay=weekday(first.day(),true);var tr=dom({type:'tr',className:o.styles.dayRow,parent:month.body});var prevMonth=hiddenWhen(offset!==0,[o.styles.dayBodyElem,o.styles.dayPrevMonth]);var nextMonth=hiddenWhen(offset!==o.monthsInCalendar-1,[o.styles.dayBodyElem,o.styles.dayNextMonth]);var disabled=o.styles.dayDisabled;var lastDay;part({base:first.clone().subtract(firstDay,'days'),length:firstDay,cell:prevMonth});part({base:first.clone(),length:total,cell:[o.styles.dayBodyElem],selectable:true});lastDay=first.clone().add(total,'days');part({base:lastDay,length:weekdayCount-tr.children.length,cell:nextMonth});back.disabled=!isInRangeLeft(first,true);next.disabled=!isInRangeRight(lastDay,true);month.date=offsetCal.clone();function part(data){var i,day,node;for(i=0;i<data.length;i++){if(tr.children.length===weekdayCount){tr=dom({type:'tr',className:o.styles.dayRow,parent:month.body});}
day=data.base.clone().add(i,'days');node=dom({type:'td',parent:tr,text:day.format(o.dayFormat),className:validationTest(day,data.cell.join(' ').split(' ')).join(' ')});if(data.selectable&&day.date()===current){selectDayElement(node);}}}
function validationTest(day,cell){if(!isInRange(day,true,o.dateValidator)){cell.push(disabled);}
return cell;}
function hiddenWhen(value,cell){if(value){cell.push(o.styles.dayConcealed);}
return cell;}}
function isInRange(date,allday,validator){if(!isInRangeLeft(date,allday)){return false;}
if(!isInRangeRight(date,allday)){return false;}
var valid=(validator||Function.prototype).call(api,date.toDate());return valid!==false;}
function isInRangeLeft(date,allday){var min=!o.min?false:(allday?o.min.clone().startOf('day'):o.min);return!min||!date.isBefore(min);}
function isInRangeRight(date,allday){var max=!o.max?false:(allday?o.max.clone().endOf('day'):o.max);return!max||!date.isAfter(max);}
function inRange(date){if(o.min&&date.isBefore(o.min)){return inRange(o.min.clone());}else if(o.max&&date.isAfter(o.max)){return inRange(o.max.clone());}
var value=date.clone().subtract(1,'days');if(validateTowards(value,date,'add')){return inTimeRange(value);}
value=date.clone();if(validateTowards(value,date,'subtract')){return inTimeRange(value);}}
function inTimeRange(value){var copy=value.clone().subtract(o.timeInterval,'seconds');var times=Math.ceil(secondsInDay/o.timeInterval);var i;for(i=0;i<times;i++){copy.add(o.timeInterval,'seconds');if(copy.date()>value.date()){copy.subtract(1,'days');}
if(o.timeValidator.call(api,copy.toDate())!==false){return copy;}}}
function validateTowards(value,date,op){var valid=false;while(valid===false){value[op](1,'days');if(value.month()!==date.month()){break;}
valid=o.dateValidator.call(api,value.toDate());}
return valid!==false;}
function pickDay(e){var target=e.target;if(classes.contains(target,o.styles.dayDisabled)||!classes.contains(target,o.styles.dayBodyElem)){return;}
var day=parseInt(text(target),10);var prev=classes.contains(target,o.styles.dayPrevMonth);var next=classes.contains(target,o.styles.dayNextMonth);var offset=getMonthOffset(target)-getMonthOffset(lastDayElement);ref.add(offset,'months');if(prev||next){ref.add(prev?-1:1,'months');}
selectDayElement(target);ref.date(day);setTime(ref,inRange(ref)||ref);refCal=ref.clone();if(o.autoClose===true){hideConditionally();}
update();}
function selectDayElement(node){if(lastDayElement){classes.remove(lastDayElement,o.styles.selectedDay);}
if(node){classes.add(node,o.styles.selectedDay);}
lastDayElement=node;}
function getMonthOffset(elem){var offset;while(elem&&elem.getAttribute){offset=elem.getAttribute(monthOffsetAttribute);if(typeof offset==='string'){return parseInt(offset,10);}
elem=elem.parentNode;}
return 0;}
function setTime(to,from){to.hour(from.hour()).minute(from.minute()).second(from.second());return to;}
function pickTime(e){var target=e.target;if(!classes.contains(target,o.styles.timeOption)){return;}
var value=momentum.moment(text(target),o.timeFormat);setTime(ref,value);refCal=ref.clone();emitValues();updateTime();if((!o.date&&o.autoClose===true)||o.autoClose==='time'){hideConditionally();}else{hideTimeList();}}
function getDate(){return ref.toDate();}
function getDateString(format){return ref.format(format||o.inputFormat);}
function getMoment(){return ref.clone();}}
module.exports=calendar;},{"./classes":56,"./clone":57,"./defaults":59,"./dom":60,"./momentum":65,"./noop":66,"./parse":67,"./text":79,"contra/emitter":47,"crossvent":51}],56:[function(require,module,exports){'use strict';var trim=/^\s+|\s+$/g;var whitespace=/\s+/;function classes(node){return node.className.replace(trim,'').split(whitespace);}
function set(node,value){node.className=value.join(' ');}
function add(node,value){var values=remove(node,value);values.push(value);set(node,values);}
function remove(node,value){var values=classes(node);var i=values.indexOf(value);if(i!==-1){values.splice(i,1);set(node,values);}
return values;}
function contains(node,value){return classes(node).indexOf(value)!==-1;}
module.exports={add:add,remove:remove,contains:contains};},{}],57:[function(require,module,exports){'use strict';var momentum=require('./momentum');function clone(thing){var copy={};var value;for(var key in thing){value=thing[key];if(!value){copy[key]=value;}else if(momentum.isMoment(value)){copy[key]=value.clone();}else if(value._isStylesConfiguration){copy[key]=clone(value);}else{copy[key]=value;}}
return copy;}
module.exports=clone;},{"./momentum":65}],58:[function(require,module,exports){'use strict';var index=require('./index');var input=require('./input');var inline=require('./inline');var isInput=require('./isInput');function core(elem,options){var cal;var existing=index.find(elem);if(existing){return existing;}
if(isInput(elem)){cal=input(elem,options);}else{cal=inline(elem,options);}
index.assign(elem,cal);return cal;}
module.exports=core;},{"./index":61,"./inline":62,"./input":63,"./isInput":64}],59:[function(require,module,exports){'use strict';var parse=require('./parse');var isInput=require('./isInput');var momentum=require('./momentum');function defaults(options,cal){var temp;var no;var o=options||{};if(o.autoHideOnClick===no){o.autoHideOnClick=true;}
if(o.autoHideOnBlur===no){o.autoHideOnBlur=true;}
if(o.autoClose===no){o.autoClose=true;}
if(o.appendTo===no){o.appendTo=document.body;}
if(o.appendTo==='parent'){if(isInput(cal.associated)){o.appendTo=cal.associated.parentNode;}else{throw new Error('Inline calendars must be appended to a parent node explicitly.');}}
if(o.invalidate===no){o.invalidate=true;}
if(o.required===no){o.required=false;}
if(o.date===no){o.date=true;}
if(o.time===no){o.time=true;}
if(o.date===false&&o.time===false){throw new Error('At least one of `date` or `time` must be `true`.');}
if(o.inputFormat===no){if(o.date&&o.time){o.inputFormat='DD-MM-YYYY HH:mm';}else if(o.date){o.inputFormat='DD-MM-YYYY';}else{o.inputFormat='HH:mm';}}
if(o.initialValue===no){o.initialValue=null;}else{o.initialValue=parse(o.initialValue,o.inputFormat);}
if(o.min===no){o.min=null;}else{o.min=parse(o.min,o.inputFormat);}
if(o.max===no){o.max=null;}else{o.max=parse(o.max,o.inputFormat);}
if(o.timeInterval===no){o.timeInterval=60*30;}
if(o.min&&o.max){if(o.max.isBefore(o.min)){temp=o.max;o.max=o.min;o.min=temp;}
if(o.date===true){if(o.max.clone().subtract(1,'days').isBefore(o.min)){throw new Error('`max` must be at least one day after `min`');}}else if(o.timeInterval*1000-o.min%(o.timeInterval*1000)>o.max-o.min){throw new Error('`min` to `max` range must allow for at least one time option that matches `timeInterval`');}}
if(o.dateValidator===no){o.dateValidator=Function.prototype;}
if(o.timeValidator===no){o.timeValidator=Function.prototype;}
if(o.timeFormat===no){o.timeFormat='HH:mm';}
if(o.weekStart===no){o.weekStart=momentum.moment().weekday(0).day();}
if(o.weekdayFormat===no){o.weekdayFormat='min';}
if(o.weekdayFormat==='long'){o.weekdayFormat=momentum.moment.weekdays();}else if(o.weekdayFormat==='short'){o.weekdayFormat=momentum.moment.weekdaysShort();}else if(o.weekdayFormat==='min'){o.weekdayFormat=momentum.moment.weekdaysMin();}else if(!Array.isArray(o.weekdayFormat)||o.weekdayFormat.length<7){throw new Error('`weekdays` must be `min`, `short`, or `long`');}
if(o.monthsInCalendar===no){o.monthsInCalendar=1;}
if(o.monthFormat===no){o.monthFormat='MMMM YYYY';}
if(o.dayFormat===no){o.dayFormat='DD';}
if(o.styles===no){o.styles={};}
o.styles._isStylesConfiguration=true;var styl=o.styles;if(styl.back===no){styl.back='rd-back';}
if(styl.container===no){styl.container='rd-container';}
if(styl.positioned===no){styl.positioned='rd-container-attachment';}
if(styl.date===no){styl.date='rd-date';}
if(styl.dayBody===no){styl.dayBody='rd-days-body';}
if(styl.dayBodyElem===no){styl.dayBodyElem='rd-day-body';}
if(styl.dayPrevMonth===no){styl.dayPrevMonth='rd-day-prev-month';}
if(styl.dayNextMonth===no){styl.dayNextMonth='rd-day-next-month';}
if(styl.dayDisabled===no){styl.dayDisabled='rd-day-disabled';}
if(styl.dayConcealed===no){styl.dayConcealed='rd-day-concealed';}
if(styl.dayHead===no){styl.dayHead='rd-days-head';}
if(styl.dayHeadElem===no){styl.dayHeadElem='rd-day-head';}
if(styl.dayRow===no){styl.dayRow='rd-days-row';}
if(styl.dayTable===no){styl.dayTable='rd-days';}
if(styl.month===no){styl.month='rd-month';}
if(styl.monthLabel===no){styl.monthLabel='rd-month-label';}
if(styl.next===no){styl.next='rd-next';}
if(styl.selectedDay===no){styl.selectedDay='rd-day-selected';}
if(styl.selectedTime===no){styl.selectedTime='rd-time-selected';}
if(styl.time===no){styl.time='rd-time';}
if(styl.timeList===no){styl.timeList='rd-time-list';}
if(styl.timeOption===no){styl.timeOption='rd-time-option';}
return o;}
module.exports=defaults;},{"./isInput":64,"./momentum":65,"./parse":67}],60:[function(require,module,exports){'use strict';function dom(options){var o=options||{};if(!o.type){o.type='div';}
var elem=document.createElement(o.type);if(o.className){elem.className=o.className;}
if(o.text){elem.innerText=elem.textContent=o.text;}
if(o.attributes){Object.keys(o.attributes).forEach(function(key){elem.setAttribute(key,o.attributes[key]);});}
if(o.parent){o.parent.appendChild(elem);}
return elem;}
module.exports=dom;},{}],61:[function(require,module,exports){'use strict';var no;var ikey='data-rome-id';var index=[];function find(thing){if(typeof thing!=='number'&&thing&&thing.getAttribute){return find(thing.getAttribute(ikey));}
var existing=index[thing];if(existing!==no){return existing;}
return null;}
function assign(elem,instance){elem.setAttribute(ikey,instance.id=index.push(instance)-1);}
module.exports={find:find,assign:assign};},{}],62:[function(require,module,exports){'use strict';var calendar=require('./calendar');function inline(elem,calendarOptions){var o=calendarOptions||{};o.appendTo=elem;o.associated=elem;var cal=calendar(o);cal.show();return cal;}
module.exports=inline;},{"./calendar":55}],63:[function(require,module,exports){'use strict';var crossvent=require('crossvent');var bullseye=require('bullseye');var throttle=require('./throttle');var clone=require('./clone');var defaults=require('./defaults');var calendar=require('./calendar');var momentum=require('./momentum');var classes=require('./classes');function inputCalendar(input,calendarOptions){var o=calendarOptions||{};o.associated=input;var api=calendar(o);var throttledTakeInput=throttle(takeInput,30);var ignoreInvalidation;var ignoreShow;var eye;init(o);return api;function init(initOptions){o=defaults(initOptions||o,api);classes.add(api.container,o.styles.positioned);crossvent.add(api.container,'mousedown',containerMouseDown);crossvent.add(api.container,'click',containerClick);api.getDate=unrequire(api.getDate);api.getDateString=unrequire(api.getDateString);api.getMoment=unrequire(api.getMoment);if(o.initialValue){input.value=o.initialValue.format(o.inputFormat);}
eye=bullseye(api.container,input);api.on('data',updateInput);api.on('show',eye.refresh);eventListening();throttledTakeInput();}
function destroy(){eventListening(true);eye.destroy();eye=null;}
function eventListening(remove){var op=remove?'remove':'add';crossvent[op](input,'click',show);crossvent[op](input,'touchend',show);crossvent[op](input,'focusin',show);crossvent[op](input,'change',throttledTakeInput);crossvent[op](input,'keypress',throttledTakeInput);crossvent[op](input,'keydown',throttledTakeInput);crossvent[op](input,'input',throttledTakeInput);if(o.invalidate){crossvent[op](input,'blur',invalidateInput);}
if(remove){api.once('ready',init);api.off('destroyed',destroy);}else{api.off('ready',init);api.once('destroyed',destroy);}}
function containerClick(){ignoreShow=true;input.focus();ignoreShow=false;}
function containerMouseDown(){ignoreInvalidation=true;setTimeout(unignore,0);function unignore(){ignoreInvalidation=false;}}
function invalidateInput(){if(!ignoreInvalidation&&!isEmpty()){api.emitValues();}}
function show(){if(ignoreShow){return;}
api.show();}
function takeInput(){var value=input.value.trim();if(isEmpty()){return;}
var date=momentum.moment(value,o.inputFormat,o.strictParse);api.setValue(date);}
function updateInput(data){input.value=data;}
function isEmpty(){return o.required===false&&input.value.trim()==='';}
function unrequire(fn){return function maybe(){return isEmpty()?null:fn.apply(this,arguments);};}}
module.exports=inputCalendar;},{"./calendar":55,"./classes":56,"./clone":57,"./defaults":59,"./momentum":65,"./throttle":80,"bullseye":34,"crossvent":51}],64:[function(require,module,exports){'use strict';function isInput(elem){return elem&&elem.nodeName&&elem.nodeName.toLowerCase()==='input';}
module.exports=isInput;},{}],65:[function(require,module,exports){'use strict';function isMoment(value){return value&&Object.prototype.hasOwnProperty.call(value,'_isAMomentObject');}
var api={moment:null,isMoment:isMoment};module.exports=api;},{}],66:[function(require,module,exports){'use strict';function noop(){}
module.exports=noop;},{}],67:[function(require,module,exports){'use strict';var momentum=require('./momentum');function raw(date,format){if(typeof date==='string'){return momentum.moment(date,format);}
if(Object.prototype.toString.call(date)==='[object Date]'){return momentum.moment(date);}
if(momentum.isMoment(date)){return date.clone();}}
function parse(date,format){var m=raw(date,typeof format==='string'?format:null);return m&&m.isValid()?m:null;}
module.exports=parse;},{"./momentum":65}],68:[function(require,module,exports){'use strict';if(!Array.prototype.filter){Array.prototype.filter=function(fn,ctx){var f=[];this.forEach(function(v,i,t){if(fn.call(ctx,v,i,t)){f.push(v);}},ctx);return f;};}},{}],69:[function(require,module,exports){'use strict';if(!Array.prototype.forEach){Array.prototype.forEach=function(fn,ctx){if(this===void 0||this===null||typeof fn!=='function'){throw new TypeError();}
var t=this;var len=t.length;for(var i=0;i<len;i++){if(i in t){fn.call(ctx,t[i],i,t);}}};}},{}],70:[function(require,module,exports){'use strict';if(!Array.prototype.indexOf){Array.prototype.indexOf=function(what,start){if(this===undefined||this===null){throw new TypeError();}
var length=this.length;start=+start||0;if(Math.abs(start)===Infinity){start=0;}else if(start<0){start+=length;if(start<0){start=0;}}
for(;start<length;start++){if(this[start]===what){return start;}}
return-1;};}},{}],71:[function(require,module,exports){'use strict';Array.isArray||(Array.isArray=function(a){return ''+a!==a&&Object.prototype.toString.call(a)==='[object Array]';});},{}],72:[function(require,module,exports){'use strict';if(!Array.prototype.map){Array.prototype.map=function(fn,ctx){var context,result,i;if(this==null){throw new TypeError('this is null or not defined');}
var source=Object(this);var len=source.length>>>0;if(typeof fn!=='function'){throw new TypeError(fn+' is not a function');}
if(arguments.length>1){context=ctx;}
result=new Array(len);i=0;while(i<len){if(i in source){result[i]=fn.call(context,source[i],i,source);}
i++;}
return result;};}},{}],73:[function(require,module,exports){'use strict';if(!Array.prototype.some){Array.prototype.some=function(fn,ctx){var context,i;if(this==null){throw new TypeError('this is null or not defined');}
var source=Object(this);var len=source.length>>>0;if(typeof fn!=='function'){throw new TypeError(fn+' is not a function');}
if(arguments.length>1){context=ctx;}
i=0;while(i<len){if(i in source){var test=fn.call(context,source[i],i,source);if(test){return true;}}
i++;}
return false;};}},{}],74:[function(require,module,exports){'use strict';if(!Function.prototype.bind){Function.prototype.bind=function(context){if(typeof this!=='function'){throw new TypeError('Function.prototype.bind - what is trying to be bound is not callable');}
var curried=Array.prototype.slice.call(arguments,1);var original=this;var NoOp=function(){};var bound=function(){var ctx=this instanceof NoOp&&context?this:context;var args=curried.concat(Array.prototype.slice.call(arguments));return original.apply(ctx,args);};NoOp.prototype=this.prototype;bound.prototype=new NoOp();return bound;};}},{}],75:[function(require,module,exports){'use strict';var hasOwn=Object.prototype.hasOwnProperty;var hasDontEnumBug=!({toString:null}).propertyIsEnumerable('toString');var dontEnums=['toString','toLocaleString','valueOf','hasOwnProperty','isPrototypeOf','propertyIsEnumerable','constructor'];var dontEnumsLength=dontEnums.length;if(!Object.keys){Object.keys=function(obj){if(typeof obj!=='object'&&(typeof obj!=='function'||obj===null)){throw new TypeError('Object.keys called on non-object');}
var result=[],prop,i;for(prop in obj){if(hasOwn.call(obj,prop)){result.push(prop);}}
if(hasDontEnumBug){for(i=0;i<dontEnumsLength;i++){if(hasOwn.call(obj,dontEnums[i])){result.push(dontEnums[i]);}}}
return result;};}},{}],76:[function(require,module,exports){'use strict';if(!String.prototype.trim){String.prototype.trim=function(){return this.replace(/^\s+|\s+$/g,'');};}},{}],77:[function(require,module,exports){'use strict';require('./polyfills/function.bind');require('./polyfills/array.foreach');require('./polyfills/array.map');require('./polyfills/array.filter');require('./polyfills/array.isarray');require('./polyfills/array.indexof');require('./polyfills/array.some');require('./polyfills/string.trim');require('./polyfills/object.keys');var core=require('./core');var index=require('./index');var use=require('./use');core.use=use.bind(core);core.find=index.find;core.val=require('./validators');module.exports=core;},{"./core":58,"./index":61,"./polyfills/array.filter":68,"./polyfills/array.foreach":69,"./polyfills/array.indexof":70,"./polyfills/array.isarray":71,"./polyfills/array.map":72,"./polyfills/array.some":73,"./polyfills/function.bind":74,"./polyfills/object.keys":75,"./polyfills/string.trim":76,"./use":81,"./validators":82}],78:[function(require,module,exports){'use strict';var moment=require('moment');var rome=require('./rome');rome.use(moment);module.exports=rome;},{"./rome":77,"moment":53}],79:[function(require,module,exports){'use strict';function text(elem,value){if(arguments.length===2){elem.innerText=elem.textContent=value;}
return elem.innerText||elem.textContent;}
module.exports=text;},{}],80:[function(require,module,exports){'use strict';module.exports=function throttle(fn,boundary){var last=-Infinity;var timer;return function bounced(){if(timer){return;}
unbound();function unbound(){clearTimeout(timer);timer=null;var next=last+boundary;var now=+new Date();if(now>next){last=now;fn.apply(this,arguments);}else{timer=setTimeout(unbound,next-now);}}};};},{}],81:[function(require,module,exports){'use strict';var momentum=require('./momentum');function use(moment){this.moment=momentum.moment=moment;}
module.exports=use;},{"./momentum":65}],82:[function(require,module,exports){'use strict';var index=require('./index');var parse=require('./parse');var association=require('./association');function compareBuilder(compare){return function factory(value){var fixed=parse(value);return function validate(date){var cal=index.find(value);var left=parse(date);var right=fixed||cal&&cal.getMoment();if(!right){return true;}
if(cal){association.add(this,cal);}
return compare(left,right);};};}
function rangeBuilder(how,compare){return function factory(start,end){var dates;var len=arguments.length;if(Array.isArray(start)){dates=start;}else{if(len===1){dates=[start];}else if(len===2){dates=[[start,end]];}}
return function validate(date){return dates.map(expand.bind(this))[how](compare.bind(this,date));};function expand(value){var start,end;var cal=index.find(value);if(cal){start=end=cal.getMoment();}else if(Array.isArray(value)){start=value[0];end=value[1];}else{start=end=value;}
if(cal){association.add(cal,this);}
return{start:parse(start).startOf('day').toDate(),end:parse(end).endOf('day').toDate()};}};}
var afterEq=compareBuilder(function(left,right){return left>=right;});var after=compareBuilder(function(left,right){return left>right;});var beforeEq=compareBuilder(function(left,right){return left<=right;});var before=compareBuilder(function(left,right){return left<right;});var except=rangeBuilder('every',function(left,right){return right.start>left||right.end<left;});var only=rangeBuilder('some',function(left,right){return right.start<=left&&right.end>=left;});module.exports={afterEq:afterEq,after:after,beforeEq:beforeEq,before:before,except:except,only:only};},{"./association":54,"./index":61,"./parse":67}]},{},[1])